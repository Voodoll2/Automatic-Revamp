/* Created by Language version: 6.2.0 */
/* VECTORIZED */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define _threadargscomma_ _p, _ppvar, _thread, _nt,
#define _threadargs_ _p, _ppvar, _thread, _nt
 
#define _threadargsprotocomma_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt,
#define _threadargsproto_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 /* Thread safe. No static _p or _ppvar. */
 
#define t _nt->_t
#define dt _nt->_dt
#define pcabar _p[0]
#define ica2 _p[1]
#define g _p[2]
#define minf _p[3]
#define taum _p[4]
#define hinf _p[5]
#define tauh _p[6]
#define m _p[7]
#define h _p[8]
#define cai _p[9]
#define cao _p[10]
#define ca2i _p[11]
#define Dm _p[12]
#define Dh _p[13]
#define T _p[14]
#define E _p[15]
#define zeta _p[16]
#define v _p[17]
#define _g _p[18]
#define _ion_cai	*_ppvar[0]._pval
#define _ion_cao	*_ppvar[1]._pval
#define _ion_ca2i	*_ppvar[2]._pval
#define _ion_ica2	*_ppvar[3]._pval
#define _ion_dica2dv	*_ppvar[4]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 static Datum* _extcall_thread;
 static Prop* _extcall_prop;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_evaluate_fct(void);
 static void _hoc_ghk(void);
 static void _hoc_kelvinfkt(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_CaT3_1_DP", _hoc_setdata,
 "evaluate_fct_CaT3_1_DP", _hoc_evaluate_fct,
 "ghk_CaT3_1_DP", _hoc_ghk,
 "kelvinfkt_CaT3_1_DP", _hoc_kelvinfkt,
 0, 0
};
#define ghk ghk_CaT3_1_DP
#define kelvinfkt kelvinfkt_CaT3_1_DP
 extern double ghk( _threadargsprotocomma_ double , double , double , double );
 extern double kelvinfkt( _threadargsprotocomma_ double );
 /* declare global and static user variables */
#define A_tau_h A_tau_h_CaT3_1_DP
 double A_tau_h = 1;
#define A_tau_m A_tau_m_CaT3_1_DP
 double A_tau_m = 1;
#define C_tau_h C_tau_h_CaT3_1_DP
 double C_tau_h = 15;
#define C_tau_m C_tau_m_CaT3_1_DP
 double C_tau_m = 1;
#define eca eca_CaT3_1_DP
 double eca = 0;
#define frac2 frac2_CaT3_1_DP
 double frac2 = 0;
#define frac1 frac1_CaT3_1_DP
 double frac1 = 0;
#define k_tau_h1 k_tau_h1_CaT3_1_DP
 double k_tau_h1 = 7;
#define k_tau_m2 k_tau_m2_CaT3_1_DP
 double k_tau_m2 = -18;
#define k_tau_m1 k_tau_m1_CaT3_1_DP
 double k_tau_m1 = 9;
#define k_h_inf k_h_inf_CaT3_1_DP
 double k_h_inf = 7;
#define k_m_inf k_m_inf_CaT3_1_DP
 double k_m_inf = -5;
#define v0_tau_h1 v0_tau_h1_CaT3_1_DP
 double v0_tau_h1 = -32;
#define v0_tau_m2 v0_tau_m2_CaT3_1_DP
 double v0_tau_m2 = -102;
#define v0_tau_m1 v0_tau_m1_CaT3_1_DP
 double v0_tau_m1 = -40;
#define v0_h_inf v0_h_inf_CaT3_1_DP
 double v0_h_inf = -72;
#define v0_m_inf v0_m_inf_CaT3_1_DP
 double v0_m_inf = -52;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "eca_CaT3_1_DP", "mV",
 "v0_m_inf_CaT3_1_DP", "mV",
 "v0_h_inf_CaT3_1_DP", "mV",
 "k_m_inf_CaT3_1_DP", "mV",
 "k_h_inf_CaT3_1_DP", "mV",
 "v0_tau_m1_CaT3_1_DP", "mV",
 "v0_tau_m2_CaT3_1_DP", "mV",
 "k_tau_m1_CaT3_1_DP", "mV",
 "k_tau_m2_CaT3_1_DP", "mV",
 "v0_tau_h1_CaT3_1_DP", "mV",
 "k_tau_h1_CaT3_1_DP", "mV",
 "pcabar_CaT3_1_DP", "cm/s",
 "ica2_CaT3_1_DP", "mA/cm2",
 "g_CaT3_1_DP", "coulombs/cm3",
 "taum_CaT3_1_DP", "ms",
 "tauh_CaT3_1_DP", "ms",
 0,0
};
 static double delta_t = 1;
 static double h0 = 0;
 static double m0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "eca_CaT3_1_DP", &eca_CaT3_1_DP,
 "v0_m_inf_CaT3_1_DP", &v0_m_inf_CaT3_1_DP,
 "v0_h_inf_CaT3_1_DP", &v0_h_inf_CaT3_1_DP,
 "k_m_inf_CaT3_1_DP", &k_m_inf_CaT3_1_DP,
 "k_h_inf_CaT3_1_DP", &k_h_inf_CaT3_1_DP,
 "C_tau_m_CaT3_1_DP", &C_tau_m_CaT3_1_DP,
 "A_tau_m_CaT3_1_DP", &A_tau_m_CaT3_1_DP,
 "v0_tau_m1_CaT3_1_DP", &v0_tau_m1_CaT3_1_DP,
 "v0_tau_m2_CaT3_1_DP", &v0_tau_m2_CaT3_1_DP,
 "k_tau_m1_CaT3_1_DP", &k_tau_m1_CaT3_1_DP,
 "k_tau_m2_CaT3_1_DP", &k_tau_m2_CaT3_1_DP,
 "C_tau_h_CaT3_1_DP", &C_tau_h_CaT3_1_DP,
 "A_tau_h_CaT3_1_DP", &A_tau_h_CaT3_1_DP,
 "v0_tau_h1_CaT3_1_DP", &v0_tau_h1_CaT3_1_DP,
 "k_tau_h1_CaT3_1_DP", &k_tau_h1_CaT3_1_DP,
 "frac1_CaT3_1_DP", &frac1_CaT3_1_DP,
 "frac2_CaT3_1_DP", &frac2_CaT3_1_DP,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[5]._i
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "6.2.0",
"CaT3_1_DP",
 "pcabar_CaT3_1_DP",
 0,
 "ica2_CaT3_1_DP",
 "g_CaT3_1_DP",
 "minf_CaT3_1_DP",
 "taum_CaT3_1_DP",
 "hinf_CaT3_1_DP",
 "tauh_CaT3_1_DP",
 0,
 "m_CaT3_1_DP",
 "h_CaT3_1_DP",
 0,
 0};
 static Symbol* _ca_sym;
 static Symbol* _ca2_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 19, _prop);
 	/*initialize range parameters*/
 	pcabar = 0.00025;
 	_prop->param = _p;
 	_prop->param_size = 19;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 6, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_ca_sym);
 nrn_promote(prop_ion, 1, 0);
 	_ppvar[0]._pval = &prop_ion->param[1]; /* cai */
 	_ppvar[1]._pval = &prop_ion->param[2]; /* cao */
 prop_ion = need_memb(_ca2_sym);
 nrn_promote(prop_ion, 1, 0);
 	_ppvar[2]._pval = &prop_ion->param[1]; /* ca2i */
 	_ppvar[3]._pval = &prop_ion->param[3]; /* ica2 */
 	_ppvar[4]._pval = &prop_ion->param[4]; /* _ion_dica2dv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*f)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _CaT3_1_DP_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("ca", -10000.);
 	ion_reg("ca2", 2.0);
 	_ca_sym = hoc_lookup("ca_ion");
 	_ca2_sym = hoc_lookup("ca2_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
  hoc_register_prop_size(_mechtype, 19, 6);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 CaT3_1_DP /projects/ps-nsg/home/nsguser/ngbw/workspace/NGBW-JOB-NEURON73_TG-2B2850FE62F34CB5983E3139C46F808C/AnwarEtAl2010/x86_64/CaT3_1_DP.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double F = 9.6485e4;
 static double R = 8.3145;
static int _reset;
static char *modelname = "Low threshold calcium current Cerebellum Purkinje Cell Model";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int evaluate_fct(_threadargsprotocomma_ double);
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static int _slist1[2], _dlist1[2];
 static int castate(_threadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset = 0; {
   evaluate_fct ( _threadargscomma_ v ) ;
   Dm = ( minf - m ) / taum ;
   Dh = ( hinf - h ) / tauh ;
   }
 return _reset;
}
 static int _ode_matsol1 (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
 evaluate_fct ( _threadargscomma_ v ) ;
 Dm = Dm  / (1. - dt*( ( ( ( - 1.0 ) ) ) / taum )) ;
 Dh = Dh  / (1. - dt*( ( ( ( - 1.0 ) ) ) / tauh )) ;
 return 0;
}
 /*END CVODE*/
 static int castate (double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) { {
   evaluate_fct ( _threadargscomma_ v ) ;
    m = m + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / taum)))*(- ( ( ( minf ) ) / taum ) / ( ( ( ( - 1.0) ) ) / taum ) - m) ;
    h = h + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / tauh)))*(- ( ( ( hinf ) ) / tauh ) / ( ( ( ( - 1.0) ) ) / tauh ) - h) ;
   }
  return 0;
}
 
double ghk ( _threadargsprotocomma_ double _lv , double _lci , double _lco , double _lz ) {
   double _lghk;
 E = ( 1e-3 ) * _lv ;
   zeta = ( _lz * F * E ) / ( R * T ) ;
   if ( fabs ( 1.0 - exp ( - zeta ) ) < 1e-6 ) {
     _lghk = ( 1e-6 ) * ( _lz * F ) * ( _lci - _lco * exp ( - zeta ) ) * ( 1.0 + zeta / 2.0 ) ;
     }
   else {
     _lghk = ( 1e-6 ) * ( _lz * zeta * F ) * ( _lci - _lco * exp ( - zeta ) ) / ( 1.0 - exp ( - zeta ) ) ;
     }
   
return _lghk;
 }
 
static void _hoc_ghk(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ghk ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) , *getarg(3) , *getarg(4) );
 hoc_retpushx(_r);
}
 
static int  evaluate_fct ( _threadargsprotocomma_ double _lv ) {
   minf = 1.0 / ( 1.0 + exp ( ( _lv - v0_m_inf ) / k_m_inf ) ) ;
   hinf = 1.0 / ( 1.0 + exp ( ( _lv - v0_h_inf ) / k_h_inf ) ) ;
   if ( _lv <= - 90.0 ) {
     taum = 1.0 ;
     }
   else {
     taum = ( C_tau_m + A_tau_m / ( exp ( ( _lv - v0_tau_m1 ) / k_tau_m1 ) + exp ( ( _lv - v0_tau_m2 ) / k_tau_m2 ) ) ) ;
     }
   tauh = ( C_tau_h + A_tau_h / exp ( ( _lv - v0_tau_h1 ) / k_tau_h1 ) ) ;
   g = ghk ( _threadargscomma_ _lv , frac1 * cai + frac2 * ca2i , ( frac1 + frac2 ) * cao , 2.0 ) ;
    return 0; }
 
static void _hoc_evaluate_fct(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r = 1.;
 evaluate_fct ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
double kelvinfkt ( _threadargsprotocomma_ double _lt ) {
   double _lkelvinfkt;
 _lkelvinfkt = 273.19 + _lt ;
   
return _lkelvinfkt;
 }
 
static void _hoc_kelvinfkt(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  kelvinfkt ( _p, _ppvar, _thread, _nt, *getarg(1) );
 hoc_retpushx(_r);
}
 
static int _ode_count(int _type){ return 2;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
  ca2i = _ion_ca2i;
     _ode_spec1 (_p, _ppvar, _thread, _nt);
  }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
	double* _p; Datum* _ppvar;
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 2; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
  ca2i = _ion_ca2i;
 _ode_matsol1 (_p, _ppvar, _thread, _nt);
 }}
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_ca_sym, _ppvar, 0, 1);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 1, 2);
   nrn_update_ion_pointer(_ca2_sym, _ppvar, 2, 1);
   nrn_update_ion_pointer(_ca2_sym, _ppvar, 3, 3);
   nrn_update_ion_pointer(_ca2_sym, _ppvar, 4, 4);
 }

static void initmodel(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
  int _i; double _save;{
  h = h0;
  m = m0;
 {
   T = kelvinfkt ( _threadargscomma_ celsius ) ;
   evaluate_fct ( _threadargscomma_ v ) ;
   m = minf ;
   h = hinf ;
   }
 
}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
  cai = _ion_cai;
  cao = _ion_cao;
  ca2i = _ion_ca2i;
 initmodel(_p, _ppvar, _thread, _nt);
 }}

static double _nrn_current(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt, double _v){double _current=0.;v=_v;{ {
   ica2 = ( 1e3 ) * pcabar * m * m * h * g ;
   }
 _current += ica2;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
  cai = _ion_cai;
  cao = _ion_cao;
  ca2i = _ion_ca2i;
 _g = _nrn_current(_p, _ppvar, _thread, _nt, _v + .001);
 	{ double _dica2;
  _dica2 = ica2;
 _rhs = _nrn_current(_p, _ppvar, _thread, _nt, _v);
  _ion_dica2dv += (_dica2 - ica2)/.001 ;
 	}
 _g = (_g - _rhs)/.001;
  _ion_ica2 += ica2 ;
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type) {
 double _break, _save;
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
  cai = _ion_cai;
  cao = _ion_cao;
  ca2i = _ion_ca2i;
 { {
 for (; t < _break; t += dt) {
   castate(_p, _ppvar, _thread, _nt);
  
}}
 t = _save;
 } }}

}

static void terminal(){}

static void _initlists(){
 double _x; double* _p = &_x;
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(m) - _p;  _dlist1[0] = &(Dm) - _p;
 _slist1[1] = &(h) - _p;  _dlist1[1] = &(Dh) - _p;
_first = 0;
}

#if defined(__cplusplus)
} /* extern "C" */
#endif
