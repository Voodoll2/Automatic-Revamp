/* Created by Language version: 6.2.0 */
/* NOT VECTORIZED */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define _threadargscomma_ /**/
#define _threadargs_ /**/
 
#define _threadargsprotocomma_ /**/
#define _threadargsproto_ /**/
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 static double *_p; static Datum *_ppvar;
 
#define t nrn_threads->_t
#define dt nrn_threads->_dt
#define ica_pmp _p[0]
#define ca (_p + 1)
#define mg (_p + 12)
#define BTC (_p + 23)
#define BTC_ca (_p + 34)
#define DMNPE (_p + 45)
#define DMNPE_ca (_p + 56)
#define CB (_p + 67)
#define CB_f_ca (_p + 78)
#define CB_ca_s (_p + 89)
#define CB_ca_ca (_p + 100)
#define iCB (_p + 111)
#define iCB_f_ca (_p + 122)
#define iCB_ca_s (_p + 133)
#define iCB_ca_ca (_p + 144)
#define PV (_p + 155)
#define PV_ca (_p + 166)
#define PV_mg (_p + 177)
#define pump _p[188]
#define pumpca _p[189]
#define ica _p[190]
#define parea _p[191]
#define cai _p[192]
#define mgi _p[193]
#define Dca (_p + 194)
#define Dmg (_p + 205)
#define DBTC (_p + 216)
#define DBTC_ca (_p + 227)
#define DDMNPE (_p + 238)
#define DDMNPE_ca (_p + 249)
#define DCB (_p + 260)
#define DCB_f_ca (_p + 271)
#define DCB_ca_s (_p + 282)
#define DCB_ca_ca (_p + 293)
#define DiCB (_p + 304)
#define DiCB_f_ca (_p + 315)
#define DiCB_ca_s (_p + 326)
#define DiCB_ca_ca (_p + 337)
#define DPV (_p + 348)
#define DPV_ca (_p + 359)
#define DPV_mg (_p + 370)
#define Dpump _p[381]
#define Dpumpca _p[382]
#define _g _p[383]
#define _ion_cao	*_ppvar[0]._pval
#define _ion_cai	*_ppvar[1]._pval
#define _ion_ica	*_ppvar[2]._pval
#define _style_ca	*((int*)_ppvar[3]._pvoid)
#define diam	*_ppvar[4]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_factors(void);
 static void _hoc_kdm(void);
 static void _hoc_kdc(void);
 static void _hoc_kds(void);
 static void _hoc_kdf(void);
 static void _hoc_ssPVmg(void);
 static void _hoc_ssPVca(void);
 static void _hoc_ssPV(void);
 static void _hoc_ssCBca(void);
 static void _hoc_ssCBslow(void);
 static void _hoc_ssCBfast(void);
 static void _hoc_ssCB(void);
 static void _hoc_ssDMNPEca(void);
 static void _hoc_ssDMNPE(void);
 static void _hoc_ssBTCca(void);
 static void _hoc_ssBTC(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _p = _prop->param; _ppvar = _prop->dparam;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_cdp3", _hoc_setdata,
 "factors_cdp3", _hoc_factors,
 "kdm_cdp3", _hoc_kdm,
 "kdc_cdp3", _hoc_kdc,
 "kds_cdp3", _hoc_kds,
 "kdf_cdp3", _hoc_kdf,
 "ssPVmg_cdp3", _hoc_ssPVmg,
 "ssPVca_cdp3", _hoc_ssPVca,
 "ssPV_cdp3", _hoc_ssPV,
 "ssCBca_cdp3", _hoc_ssCBca,
 "ssCBslow_cdp3", _hoc_ssCBslow,
 "ssCBfast_cdp3", _hoc_ssCBfast,
 "ssCB_cdp3", _hoc_ssCB,
 "ssDMNPEca_cdp3", _hoc_ssDMNPEca,
 "ssDMNPE_cdp3", _hoc_ssDMNPE,
 "ssBTCca_cdp3", _hoc_ssBTCca,
 "ssBTC_cdp3", _hoc_ssBTC,
 0, 0
};
#define kdm kdm_cdp3
#define kdc kdc_cdp3
#define kds kds_cdp3
#define kdf kdf_cdp3
#define ssPVmg ssPVmg_cdp3
#define ssPVca ssPVca_cdp3
#define ssPV ssPV_cdp3
#define ssCBca ssCBca_cdp3
#define ssCBslow ssCBslow_cdp3
#define ssCBfast ssCBfast_cdp3
#define ssCB ssCB_cdp3
#define ssDMNPEca ssDMNPEca_cdp3
#define ssDMNPE ssDMNPE_cdp3
#define ssBTCca ssBTCca_cdp3
#define ssBTC ssBTC_cdp3
 extern double kdm( );
 extern double kdc( );
 extern double kds( );
 extern double kdf( );
 extern double ssPVmg( double , double );
 extern double ssPVca( double , double );
 extern double ssPV( double , double );
 extern double ssCBca( double , double );
 extern double ssCBslow( double , double );
 extern double ssCBfast( double , double );
 extern double ssCB( double , double );
 extern double ssDMNPEca( );
 extern double ssDMNPE( );
 extern double ssBTCca( );
 extern double ssBTC( );
 /* declare global and static user variables */
#define BTCnull BTCnull_cdp3
 double BTCnull = 0;
#define CBnull CBnull_cdp3
 double CBnull = 0.16;
#define DMNPEnull DMNPEnull_cdp3
 double DMNPEnull = 0;
#define Dpar Dpar_cdp3
 double Dpar = 0.043;
#define Dcbd2 Dcbd2_cdp3
 double Dcbd2 = 0;
#define Dcbd1 Dcbd1_cdp3
 double Dcbd1 = 0.028;
#define Ddmnpe Ddmnpe_cdp3
 double Ddmnpe = 0.08;
#define Dbtc Dbtc_cdp3
 double Dbtc = 0.007;
#define DCa DCa_cdp3
 double DCa = 0.233;
#define PVnull PVnull_cdp3
 double PVnull = 0.08;
#define TotalPump TotalPump_cdp3
 double TotalPump = 1e-09;
#define b2 b2_cdp3
 double b2 = 0.08;
#define b1 b1_cdp3
 double b1 = 5.33;
#define c2 c2_cdp3
 double c2 = 0.000107;
#define c1 c1_cdp3
 double c1 = 5.63;
#define cainull cainull_cdp3
 double cainull = 4.5e-05;
#define kpmp3 kpmp3_cdp3
 double kpmp3 = 7.255e-05;
#define kpmp2 kpmp2_cdp3
 double kpmp2 = 1.75e-05;
#define kpmp1 kpmp1_cdp3
 double kpmp1 = 0.003;
#define m2 m2_cdp3
 double m2 = 0.00095;
#define m1 m1_cdp3
 double m1 = 107;
#define mginull mginull_cdp3
 double mginull = 0.59;
#define ns2 ns2_cdp3
 double ns2 = 0.0026;
#define ns1 ns1_cdp3
 double ns1 = 5.5;
#define nf2 nf2_cdp3
 double nf2 = 0.0358;
#define nf1 nf1_cdp3
 double nf1 = 43.5;
#define p2 p2_cdp3
 double p2 = 0.025;
#define p1 p1_cdp3
 double p1 = 0.8;
#define vrat vrat_cdp3
 double vrat[11];
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "cainull_cdp3", "mM",
 "mginull_cdp3", "mM",
 "DCa_cdp3", "um2/ms",
 "Dbtc_cdp3", "um2/ms",
 "Ddmnpe_cdp3", "um2/ms",
 "Dcbd1_cdp3", "um2/ms",
 "Dcbd2_cdp3", "um2/ms",
 "Dpar_cdp3", "um2/ms",
 "BTCnull_cdp3", "mM",
 "b1_cdp3", "/ms",
 "b2_cdp3", "/ms",
 "DMNPEnull_cdp3", "mM",
 "c1_cdp3", "/ms",
 "c2_cdp3", "/ms",
 "CBnull_cdp3", "mM",
 "nf1_cdp3", "/ms",
 "nf2_cdp3", "/ms",
 "ns1_cdp3", "/ms",
 "ns2_cdp3", "/ms",
 "PVnull_cdp3", "mM",
 "m1_cdp3", "/ms",
 "m2_cdp3", "/ms",
 "p1_cdp3", "/ms",
 "p2_cdp3", "/ms",
 "kpmp1_cdp3", "/mM-ms",
 "kpmp2_cdp3", "/ms",
 "kpmp3_cdp3", "/ms",
 "TotalPump_cdp3", "mol/cm2",
 "vrat_cdp3", "1",
 "ca_cdp3", "mM",
 "mg_cdp3", "mM",
 "BTC_cdp3", "mM",
 "BTC_ca_cdp3", "mM",
 "DMNPE_cdp3", "mM",
 "DMNPE_ca_cdp3", "mM",
 "CB_cdp3", "mM",
 "CB_f_ca_cdp3", "mM",
 "CB_ca_s_cdp3", "mM",
 "CB_ca_ca_cdp3", "mM",
 "iCB_cdp3", "mM",
 "iCB_f_ca_cdp3", "mM",
 "iCB_ca_s_cdp3", "mM",
 "iCB_ca_ca_cdp3", "mM",
 "PV_cdp3", "mM",
 "PV_ca_cdp3", "mM",
 "PV_mg_cdp3", "mM",
 "pump_cdp3", "mol/cm2",
 "pumpca_cdp3", "mol/cm2",
 "ica_pmp_cdp3", "mA/cm2",
 0,0
};
 static double BTC_ca0 = 0;
 static double BTC0 = 0;
 static double CB_ca_ca0 = 0;
 static double CB_ca_s0 = 0;
 static double CB_f_ca0 = 0;
 static double CB0 = 0;
 static double DMNPE_ca0 = 0;
 static double DMNPE0 = 0;
 static double PV_mg0 = 0;
 static double PV_ca0 = 0;
 static double PV0 = 0;
 static double ca0 = 0;
 static double delta_t = 0.01;
 static double iCB_ca_ca0 = 0;
 static double iCB_ca_s0 = 0;
 static double iCB_f_ca0 = 0;
 static double iCB0 = 0;
 static double mg0 = 0;
 static double pumpca0 = 0;
 static double pump0 = 0;
 static double v = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "cainull_cdp3", &cainull_cdp3,
 "mginull_cdp3", &mginull_cdp3,
 "DCa_cdp3", &DCa_cdp3,
 "Dbtc_cdp3", &Dbtc_cdp3,
 "Ddmnpe_cdp3", &Ddmnpe_cdp3,
 "Dcbd1_cdp3", &Dcbd1_cdp3,
 "Dcbd2_cdp3", &Dcbd2_cdp3,
 "Dpar_cdp3", &Dpar_cdp3,
 "BTCnull_cdp3", &BTCnull_cdp3,
 "b1_cdp3", &b1_cdp3,
 "b2_cdp3", &b2_cdp3,
 "DMNPEnull_cdp3", &DMNPEnull_cdp3,
 "c1_cdp3", &c1_cdp3,
 "c2_cdp3", &c2_cdp3,
 "CBnull_cdp3", &CBnull_cdp3,
 "nf1_cdp3", &nf1_cdp3,
 "nf2_cdp3", &nf2_cdp3,
 "ns1_cdp3", &ns1_cdp3,
 "ns2_cdp3", &ns2_cdp3,
 "PVnull_cdp3", &PVnull_cdp3,
 "m1_cdp3", &m1_cdp3,
 "m2_cdp3", &m2_cdp3,
 "p1_cdp3", &p1_cdp3,
 "p2_cdp3", &p2_cdp3,
 "kpmp1_cdp3", &kpmp1_cdp3,
 "kpmp2_cdp3", &kpmp2_cdp3,
 "kpmp3_cdp3", &kpmp3_cdp3,
 "TotalPump_cdp3", &TotalPump_cdp3,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 "vrat_cdp3", vrat_cdp3, 11,
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[5]._i
 static void _ode_synonym(int, double**, Datum**);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "6.2.0",
"cdp3",
 0,
 "ica_pmp_cdp3",
 0,
 "ca_cdp3[11]",
 "mg_cdp3[11]",
 "BTC_cdp3[11]",
 "BTC_ca_cdp3[11]",
 "DMNPE_cdp3[11]",
 "DMNPE_ca_cdp3[11]",
 "CB_cdp3[11]",
 "CB_f_ca_cdp3[11]",
 "CB_ca_s_cdp3[11]",
 "CB_ca_ca_cdp3[11]",
 "iCB_cdp3[11]",
 "iCB_f_ca_cdp3[11]",
 "iCB_ca_s_cdp3[11]",
 "iCB_ca_ca_cdp3[11]",
 "PV_cdp3[11]",
 "PV_ca_cdp3[11]",
 "PV_mg_cdp3[11]",
 "pump_cdp3",
 "pumpca_cdp3",
 0,
 0};
 static Symbol* _morphology_sym;
 static Symbol* _ca_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 384, _prop);
 	/*initialize range parameters*/
 	_prop->param = _p;
 	_prop->param_size = 384;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 6, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_morphology_sym);
 	_ppvar[4]._pval = &prop_ion->param[0]; /* diam */
 prop_ion = need_memb(_ca_sym);
 nrn_check_conc_write(_prop, prop_ion, 1);
 nrn_promote(prop_ion, 3, 0);
 	_ppvar[0]._pval = &prop_ion->param[2]; /* cao */
 	_ppvar[1]._pval = &prop_ion->param[1]; /* cai */
 	_ppvar[2]._pval = &prop_ion->param[3]; /* ica */
 	_ppvar[3]._pvoid = (void*)(&(prop_ion->dparam[0]._i)); /* iontype for ca */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 "mg_cdp3", 1e-07,
 "pump_cdp3", 1e-15,
 "pumpca_cdp3", 1e-15,
 0,0
};
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*f)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _cdp3_reg() {
	int _vectorized = 0;
  _initlists();
 	ion_reg("ca", -10000.);
 	_morphology_sym = hoc_lookup("morphology");
 	_ca_sym = hoc_lookup("ca_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 0);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
  hoc_register_prop_size(_mechtype, 384, 6);
 	nrn_writes_conc(_mechtype, 0);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_synonym(_mechtype, _ode_synonym);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 cdp3 /projects/ps-nsg/home/nsguser/ngbw/workspace/NGBW-JOB-NEURON73_TG-2B2850FE62F34CB5983E3139C46F808C/AnwarEtAl2010/x86_64/cdp3.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double FARADAY = 9.64853;
 static double PI = 3.14159;
 static double cao = 2;
 static double _zfactors_done ;
 static double _zfrat [ 11 ] ;
 static double _zdsq , _zdsqvol ;
static int _reset;
static char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int factors();
 extern double *_getelm();
 
#define _MATELM1(_row,_col)	*(_getelm(_row + 1, _col + 1))
 
#define _RHS1(_arg) _coef1[_arg + 1]
 static double *_coef1;
 
#define _linmat1  0
 static void* _sparseobj1;
 static void* _cvsparseobj1;
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static int _slist1[189], _dlist1[189]; static double *_temp1;
 static int state();
 
static int  factors (  ) {
   double _lr , _ldr2 ;
 _lr = 1.0 / 2.0 ;
   _ldr2 = _lr / ( 11.0 - 1.0 ) / 2.0 ;
   vrat [ 0 ] = 0.0 ;
   _zfrat [ 0 ] = 2.0 * _lr ;
   {int  _li ;for ( _li = 0 ; _li <= 11 - 2 ; _li ++ ) {
     vrat [ _li ] = vrat [ _li ] + PI * ( _lr - _ldr2 / 2.0 ) * 2.0 * _ldr2 ;
     _lr = _lr - _ldr2 ;
     _zfrat [ _li + 1 ] = 2.0 * PI * _lr / ( 2.0 * _ldr2 ) ;
     _lr = _lr - _ldr2 ;
     vrat [ _li + 1 ] = PI * ( _lr + _ldr2 / 2.0 ) * 2.0 * _ldr2 ;
     } }
    return 0; }
 
static void _hoc_factors(void) {
  double _r;
   _r = 1.;
 factors (  );
 hoc_retpushx(_r);
}
 
static int state ()
 {_reset=0;
 {
   double b_flux, f_flux, _term; int _i;
 {int _i; double _dt1 = 1.0/dt;
for(_i=1;_i<189;_i++){
  	_RHS1(_i) = -_dt1*(_p[_slist1[_i]] - _p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
}  
_RHS1(188) *= ( ( 1e10 ) * parea) ;
_MATELM1(188, 188) *= ( ( 1e10 ) * parea);  
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 1) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 1, _i + 1) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 12) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 12, _i + 12) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 23) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 23, _i + 23) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 34) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 34, _i + 34) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 45) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 45, _i + 45) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 56) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 56, _i + 56) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 67) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 67, _i + 67) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 78) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 78, _i + 78) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 89) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 89, _i + 89) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 100) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 100, _i + 100) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 111) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 111, _i + 111) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 122) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 122, _i + 122) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 133) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 133, _i + 133) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 144) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 144, _i + 144) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 155) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 155, _i + 155) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 166) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 166, _i + 166) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 177) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 177, _i + 177) *= ( diam * diam * vrat [ ((int) _i ) ]);  } }
 /* COMPARTMENT _li , diam * diam * vrat [ ((int) _i ) ] {
     ca mg BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca iCB iCB_f_ca iCB_ca_s iCB_ca_ca PV PV_ca PV_mg }
   */
 /* COMPARTMENT ( 1e10 ) * parea {
     pump pumpca }
   */
 /* ~ ca [ 0 ] + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 f_flux =  kpmp1 * parea * ( 1e10 ) * pump * ca [ 0] ;
 b_flux =  kpmp2 * parea * ( 1e10 ) * pumpca ;
 _RHS1( 188) -= (f_flux - b_flux);
 _RHS1( 122 +  0) -= (f_flux - b_flux);
 
 _term =  kpmp1 * parea * ( 1e10 ) * ca [ 0] ;
 _MATELM1( 188 ,188)  += _term;
 _MATELM1( 122 +  0 ,188)  += _term;
 _term =  kpmp1 * parea * ( 1e10 ) * pump ;
 _MATELM1( 188 ,122 +  0)  += _term;
 _MATELM1( 122 +  0 ,122 +  0)  += _term;
 _term =  kpmp2 * parea * ( 1e10 ) ;
 _MATELM1( 188 ,0)  -= _term;
 _MATELM1( 122 +  0 ,0)  -= _term;
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 f_flux =  kpmp3 * parea * ( 1e10 ) * pumpca ;
 b_flux =  0.0 * pump ;
 _RHS1( 188) += (f_flux - b_flux);
 
 _term =  kpmp3 * parea * ( 1e10 ) ;
 _MATELM1( 188 ,0)  -= _term;
 _term =  0.0 ;
 _MATELM1( 188 ,188)  += _term;
 /*REACTION*/
   /* pump + pumpca = TotalPump * parea * ( 1e10 ) */
 _RHS1(0) =  TotalPump * parea * ( 1e10 );
 _MATELM1(0, 0) = 1 * ( ( 1e10 ) * parea);
 _RHS1(0) -= pumpca * ( ( 1e10 ) * parea) ;
 _MATELM1(0, 188) = 1 * ( ( 1e10 ) * parea);
 _RHS1(0) -= pump * ( ( 1e10 ) * parea) ;
 /*CONSERVATION*/
 ica_pmp = 2.0 * FARADAY * ( f_flux - b_flux ) / parea ;
   /* ~ ca [ 0 ] < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 f_flux = b_flux = 0.;
 _RHS1( 122 +  0) += (b_flux =   ( - ica * PI * diam / ( 2.0 * FARADAY ) ) );
 /*FLUX*/
  {int  _li ;for ( _li = 0 ; _li <= 11 - 2 ; _li ++ ) {
     /* ~ ca [ _li ] <-> ca [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 f_flux =  DCa * _zfrat [ _li + 1 ] * ca [ _li] ;
 b_flux =  DCa * _zfrat [ _li + 1 ] * ca [ _li + 1] ;
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li + 1) += (f_flux - b_flux);
 
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li + 1 ,122 +  _li)  -= _term;
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 122 +  _li ,122 +  _li + 1)  -= _term;
 _MATELM1( 122 +  _li + 1 ,122 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ mg [ _li ] <-> mg [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 f_flux =  DCa * _zfrat [ _li + 1 ] * mg [ _li] ;
 b_flux =  DCa * _zfrat [ _li + 1 ] * mg [ _li + 1] ;
 _RHS1( 177 +  _li) -= (f_flux - b_flux);
 _RHS1( 177 +  _li + 1) += (f_flux - b_flux);
 
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 177 +  _li ,177 +  _li)  += _term;
 _MATELM1( 177 +  _li + 1 ,177 +  _li)  -= _term;
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 177 +  _li ,177 +  _li + 1)  -= _term;
 _MATELM1( 177 +  _li + 1 ,177 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ BTC [ _li ] <-> BTC [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 f_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC [ _li] ;
 b_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC [ _li + 1] ;
 _RHS1( 12 +  _li) -= (f_flux - b_flux);
 _RHS1( 12 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 12 +  _li ,12 +  _li)  += _term;
 _MATELM1( 12 +  _li + 1 ,12 +  _li)  -= _term;
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 12 +  _li ,12 +  _li + 1)  -= _term;
 _MATELM1( 12 +  _li + 1 ,12 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ BTC_ca [ _li ] <-> BTC_ca [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 f_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC_ca [ _li] ;
 b_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC_ca [ _li + 1] ;
 _RHS1( 1 +  _li) -= (f_flux - b_flux);
 _RHS1( 1 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 1 +  _li ,1 +  _li)  += _term;
 _MATELM1( 1 +  _li + 1 ,1 +  _li)  -= _term;
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 1 +  _li ,1 +  _li + 1)  -= _term;
 _MATELM1( 1 +  _li + 1 ,1 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ DMNPE [ _li ] <-> DMNPE [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 f_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE [ _li] ;
 b_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE [ _li + 1] ;
 _RHS1( 78 +  _li) -= (f_flux - b_flux);
 _RHS1( 78 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 78 +  _li ,78 +  _li)  += _term;
 _MATELM1( 78 +  _li + 1 ,78 +  _li)  -= _term;
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 78 +  _li ,78 +  _li + 1)  -= _term;
 _MATELM1( 78 +  _li + 1 ,78 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ DMNPE_ca [ _li ] <-> DMNPE_ca [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 f_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE_ca [ _li] ;
 b_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE_ca [ _li + 1] ;
 _RHS1( 67 +  _li) -= (f_flux - b_flux);
 _RHS1( 67 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 67 +  _li ,67 +  _li)  += _term;
 _MATELM1( 67 +  _li + 1 ,67 +  _li)  -= _term;
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 67 +  _li ,67 +  _li + 1)  -= _term;
 _MATELM1( 67 +  _li + 1 ,67 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB [ _li ] <-> CB [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB [ _li + 1] ;
 _RHS1( 56 +  _li) -= (f_flux - b_flux);
 _RHS1( 56 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 56 +  _li + 1 ,56 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 56 +  _li ,56 +  _li + 1)  -= _term;
 _MATELM1( 56 +  _li + 1 ,56 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_f_ca [ _li ] <-> CB_f_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_f_ca [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_f_ca [ _li + 1] ;
 _RHS1( 45 +  _li) -= (f_flux - b_flux);
 _RHS1( 45 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 _MATELM1( 45 +  _li + 1 ,45 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 45 +  _li ,45 +  _li + 1)  -= _term;
 _MATELM1( 45 +  _li + 1 ,45 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_ca_s [ _li ] <-> CB_ca_s [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_s [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_s [ _li + 1] ;
 _RHS1( 34 +  _li) -= (f_flux - b_flux);
 _RHS1( 34 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 _MATELM1( 34 +  _li + 1 ,34 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 34 +  _li ,34 +  _li + 1)  -= _term;
 _MATELM1( 34 +  _li + 1 ,34 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_ca_ca [ _li ] <-> CB_ca_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_ca [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_ca [ _li + 1] ;
 _RHS1( 23 +  _li) -= (f_flux - b_flux);
 _RHS1( 23 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 _MATELM1( 23 +  _li + 1 ,23 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 23 +  _li ,23 +  _li + 1)  -= _term;
 _MATELM1( 23 +  _li + 1 ,23 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV [ _li ] <-> PV [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV [ _li + 1] ;
 _RHS1( 111 +  _li) -= (f_flux - b_flux);
 _RHS1( 111 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 111 +  _li + 1 ,111 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 111 +  _li ,111 +  _li + 1)  -= _term;
 _MATELM1( 111 +  _li + 1 ,111 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV_ca [ _li ] <-> PV_ca [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV_ca [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV_ca [ _li + 1] ;
 _RHS1( 100 +  _li) -= (f_flux - b_flux);
 _RHS1( 100 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 100 +  _li ,100 +  _li)  += _term;
 _MATELM1( 100 +  _li + 1 ,100 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 100 +  _li ,100 +  _li + 1)  -= _term;
 _MATELM1( 100 +  _li + 1 ,100 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV_mg [ _li ] <-> PV_mg [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV_mg [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV_mg [ _li + 1] ;
 _RHS1( 89 +  _li) -= (f_flux - b_flux);
 _RHS1( 89 +  _li + 1) += (f_flux - b_flux);
 
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 89 +  _li ,89 +  _li)  += _term;
 _MATELM1( 89 +  _li + 1 ,89 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 89 +  _li ,89 +  _li + 1)  -= _term;
 _MATELM1( 89 +  _li + 1 ,89 +  _li + 1)  += _term;
 /*REACTION*/
  } }
   _zdsq = diam * diam ;
   {int  _li ;for ( _li = 0 ; _li <= 11 - 1 ; _li ++ ) {
     _zdsqvol = _zdsq * vrat [ _li ] ;
     /* ~ ca [ _li ] + BTC [ _li ] <-> BTC_ca [ _li ] ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 f_flux =  b1 * _zdsqvol * BTC [ _li] * ca [ _li] ;
 b_flux =  b2 * _zdsqvol * BTC_ca [ _li] ;
 _RHS1( 12 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 1 +  _li) += (f_flux - b_flux);
 
 _term =  b1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 12 +  _li ,12 +  _li)  += _term;
 _MATELM1( 122 +  _li ,12 +  _li)  += _term;
 _MATELM1( 1 +  _li ,12 +  _li)  -= _term;
 _term =  b1 * _zdsqvol * BTC [ _li] ;
 _MATELM1( 12 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 1 +  _li ,122 +  _li)  -= _term;
 _term =  b2 * _zdsqvol ;
 _MATELM1( 12 +  _li ,1 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,1 +  _li)  -= _term;
 _MATELM1( 1 +  _li ,1 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + DMNPE [ _li ] <-> DMNPE_ca [ _li ] ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 f_flux =  c1 * _zdsqvol * DMNPE [ _li] * ca [ _li] ;
 b_flux =  c2 * _zdsqvol * DMNPE_ca [ _li] ;
 _RHS1( 78 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 67 +  _li) += (f_flux - b_flux);
 
 _term =  c1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 78 +  _li ,78 +  _li)  += _term;
 _MATELM1( 122 +  _li ,78 +  _li)  += _term;
 _MATELM1( 67 +  _li ,78 +  _li)  -= _term;
 _term =  c1 * _zdsqvol * DMNPE [ _li] ;
 _MATELM1( 78 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 67 +  _li ,122 +  _li)  -= _term;
 _term =  c2 * _zdsqvol ;
 _MATELM1( 78 +  _li ,67 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,67 +  _li)  -= _term;
 _MATELM1( 67 +  _li ,67 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * CB_ca_s [ _li] ;
 _RHS1( 56 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 34 +  _li) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 122 +  _li ,56 +  _li)  += _term;
 _MATELM1( 34 +  _li ,56 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * CB [ _li] ;
 _MATELM1( 56 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 34 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 56 +  _li ,34 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,34 +  _li)  -= _term;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * CB_f_ca [ _li] ;
 _RHS1( 56 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 45 +  _li) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 122 +  _li ,56 +  _li)  += _term;
 _MATELM1( 45 +  _li ,56 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * CB [ _li] ;
 _MATELM1( 56 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 45 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 56 +  _li ,45 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,45 +  _li)  -= _term;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB_f_ca [ _li ] <-> CB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB_f_ca [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * CB_ca_ca [ _li] ;
 _RHS1( 45 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 23 +  _li) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 _MATELM1( 122 +  _li ,45 +  _li)  += _term;
 _MATELM1( 23 +  _li ,45 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * CB_f_ca [ _li] ;
 _MATELM1( 45 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 23 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 45 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB_ca_s [ _li ] <-> CB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB_ca_s [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * CB_ca_ca [ _li] ;
 _RHS1( 34 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 23 +  _li) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 _MATELM1( 122 +  _li ,34 +  _li)  += _term;
 _MATELM1( 23 +  _li ,34 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * CB_ca_s [ _li] ;
 _MATELM1( 34 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 23 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 34 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * iCB [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * iCB_ca_s [ _li] ;
 _RHS1( 166 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 144 +  _li) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 166 +  _li ,166 +  _li)  += _term;
 _MATELM1( 122 +  _li ,166 +  _li)  += _term;
 _MATELM1( 144 +  _li ,166 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * iCB [ _li] ;
 _MATELM1( 166 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 144 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 166 +  _li ,144 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,144 +  _li)  -= _term;
 _MATELM1( 144 +  _li ,144 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * iCB [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * iCB_f_ca [ _li] ;
 _RHS1( 166 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 155 +  _li) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 166 +  _li ,166 +  _li)  += _term;
 _MATELM1( 122 +  _li ,166 +  _li)  += _term;
 _MATELM1( 155 +  _li ,166 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * iCB [ _li] ;
 _MATELM1( 166 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 155 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 166 +  _li ,155 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,155 +  _li)  -= _term;
 _MATELM1( 155 +  _li ,155 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_f_ca [ _li ] <-> iCB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * iCB_f_ca [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * iCB_ca_ca [ _li] ;
 _RHS1( 155 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 133 +  _li) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 155 +  _li ,155 +  _li)  += _term;
 _MATELM1( 122 +  _li ,155 +  _li)  += _term;
 _MATELM1( 133 +  _li ,155 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * iCB_f_ca [ _li] ;
 _MATELM1( 155 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 133 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 155 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 133 +  _li ,133 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_ca_s [ _li ] <-> iCB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * iCB_ca_s [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * iCB_ca_ca [ _li] ;
 _RHS1( 144 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 133 +  _li) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 144 +  _li ,144 +  _li)  += _term;
 _MATELM1( 122 +  _li ,144 +  _li)  += _term;
 _MATELM1( 133 +  _li ,144 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * iCB_ca_s [ _li] ;
 _MATELM1( 144 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 133 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 144 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 133 +  _li ,133 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + PV [ _li ] <-> PV_ca [ _li ] ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 f_flux =  m1 * _zdsqvol * PV [ _li] * ca [ _li] ;
 b_flux =  m2 * _zdsqvol * PV_ca [ _li] ;
 _RHS1( 111 +  _li) -= (f_flux - b_flux);
 _RHS1( 122 +  _li) -= (f_flux - b_flux);
 _RHS1( 100 +  _li) += (f_flux - b_flux);
 
 _term =  m1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 122 +  _li ,111 +  _li)  += _term;
 _MATELM1( 100 +  _li ,111 +  _li)  -= _term;
 _term =  m1 * _zdsqvol * PV [ _li] ;
 _MATELM1( 111 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 100 +  _li ,122 +  _li)  -= _term;
 _term =  m2 * _zdsqvol ;
 _MATELM1( 111 +  _li ,100 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,100 +  _li)  -= _term;
 _MATELM1( 100 +  _li ,100 +  _li)  += _term;
 /*REACTION*/
  /* ~ mg [ _li ] + PV [ _li ] <-> PV_mg [ _li ] ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 f_flux =  p1 * _zdsqvol * PV [ _li] * mg [ _li] ;
 b_flux =  p2 * _zdsqvol * PV_mg [ _li] ;
 _RHS1( 111 +  _li) -= (f_flux - b_flux);
 _RHS1( 177 +  _li) -= (f_flux - b_flux);
 _RHS1( 89 +  _li) += (f_flux - b_flux);
 
 _term =  p1 * _zdsqvol * mg [ _li] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 177 +  _li ,111 +  _li)  += _term;
 _MATELM1( 89 +  _li ,111 +  _li)  -= _term;
 _term =  p1 * _zdsqvol * PV [ _li] ;
 _MATELM1( 111 +  _li ,177 +  _li)  += _term;
 _MATELM1( 177 +  _li ,177 +  _li)  += _term;
 _MATELM1( 89 +  _li ,177 +  _li)  -= _term;
 _term =  p2 * _zdsqvol ;
 _MATELM1( 111 +  _li ,89 +  _li)  -= _term;
 _MATELM1( 177 +  _li ,89 +  _li)  -= _term;
 _MATELM1( 89 +  _li ,89 +  _li)  += _term;
 /*REACTION*/
  } }
   cai = ca [ 0 ] ;
   mgi = mg [ 0 ] ;
     } return _reset;
 }
 
double ssBTC (  ) {
   double _lssBTC;
 _lssBTC = BTCnull / ( 1.0 + ( ( b1 / b2 ) * cainull ) ) ;
   
return _lssBTC;
 }
 
static void _hoc_ssBTC(void) {
  double _r;
   _r =  ssBTC (  );
 hoc_retpushx(_r);
}
 
double ssBTCca (  ) {
   double _lssBTCca;
 _lssBTCca = BTCnull / ( 1.0 + ( b2 / ( b1 * cainull ) ) ) ;
   
return _lssBTCca;
 }
 
static void _hoc_ssBTCca(void) {
  double _r;
   _r =  ssBTCca (  );
 hoc_retpushx(_r);
}
 
double ssDMNPE (  ) {
   double _lssDMNPE;
 _lssDMNPE = DMNPEnull / ( 1.0 + ( ( c1 / c2 ) * cainull ) ) ;
   
return _lssDMNPE;
 }
 
static void _hoc_ssDMNPE(void) {
  double _r;
   _r =  ssDMNPE (  );
 hoc_retpushx(_r);
}
 
double ssDMNPEca (  ) {
   double _lssDMNPEca;
 _lssDMNPEca = DMNPEnull / ( 1.0 + ( c2 / ( c1 * cainull ) ) ) ;
   
return _lssDMNPEca;
 }
 
static void _hoc_ssDMNPEca(void) {
  double _r;
   _r =  ssDMNPEca (  );
 hoc_retpushx(_r);
}
 
double ssCB (  double _lkdf , double _lkds ) {
   double _lssCB;
 _lssCB = CBnull / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCB;
 }
 
static void _hoc_ssCB(void) {
  double _r;
   _r =  ssCB (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBfast (  double _lkdf , double _lkds ) {
   double _lssCBfast;
 _lssCBfast = ( CBnull * kds ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBfast;
 }
 
static void _hoc_ssCBfast(void) {
  double _r;
   _r =  ssCBfast (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBslow (  double _lkdf , double _lkds ) {
   double _lssCBslow;
 _lssCBslow = ( CBnull * kdf ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBslow;
 }
 
static void _hoc_ssCBslow(void) {
  double _r;
   _r =  ssCBslow (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBca (  double _lkdf , double _lkds ) {
   double _lssCBca;
 _lssCBca = ( CBnull * kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBca;
 }
 
static void _hoc_ssCBca(void) {
  double _r;
   _r =  ssCBca (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double kdf (  ) {
   double _lkdf;
 _lkdf = ( cainull * nf1 ) / nf2 ;
   
return _lkdf;
 }
 
static void _hoc_kdf(void) {
  double _r;
   _r =  kdf (  );
 hoc_retpushx(_r);
}
 
double kds (  ) {
   double _lkds;
 _lkds = ( cainull * ns1 ) / ns2 ;
   
return _lkds;
 }
 
static void _hoc_kds(void) {
  double _r;
   _r =  kds (  );
 hoc_retpushx(_r);
}
 
double kdc (  ) {
   double _lkdc;
 _lkdc = ( cainull * m1 ) / m2 ;
   
return _lkdc;
 }
 
static void _hoc_kdc(void) {
  double _r;
   _r =  kdc (  );
 hoc_retpushx(_r);
}
 
double kdm (  ) {
   double _lkdm;
 _lkdm = ( mginull * p1 ) / p2 ;
   
return _lkdm;
 }
 
static void _hoc_kdm(void) {
  double _r;
   _r =  kdm (  );
 hoc_retpushx(_r);
}
 
double ssPV (  double _lkdc , double _lkdm ) {
   double _lssPV;
 _lssPV = PVnull / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPV;
 }
 
static void _hoc_ssPV(void) {
  double _r;
   _r =  ssPV (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssPVca (  double _lkdc , double _lkdm ) {
   double _lssPVca;
 _lssPVca = ( PVnull * kdc ( _threadargs_ ) ) / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPVca;
 }
 
static void _hoc_ssPVca(void) {
  double _r;
   _r =  ssPVca (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssPVmg (  double _lkdc , double _lkdm ) {
   double _lssPVmg;
 _lssPVmg = ( PVnull * kdm ( _threadargs_ ) ) / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPVmg;
 }
 
static void _hoc_ssPVmg(void) {
  double _r;
   _r =  ssPVmg (  *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
/*CVODE ode begin*/
 static int _ode_spec1() {_reset=0;{
 double b_flux, f_flux, _term; int _i;
 {int _i; for(_i=0;_i<189;_i++) _p[_dlist1[_i]] = 0.0;}
 /* COMPARTMENT _li , diam * diam * vrat [ ((int) _i ) ] {
   ca mg BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca iCB iCB_f_ca iCB_ca_s iCB_ca_ca PV PV_ca PV_mg }
 */
 /* COMPARTMENT ( 1e10 ) * parea {
   pump pumpca }
 */
 /* ~ ca [ 0 ] + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 f_flux =  kpmp1 * parea * ( 1e10 ) * pump * ca [ 0] ;
 b_flux =  kpmp2 * parea * ( 1e10 ) * pumpca ;
 Dpump -= (f_flux - b_flux);
 Dca [ 0] -= (f_flux - b_flux);
 Dpumpca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 f_flux =  kpmp3 * parea * ( 1e10 ) * pumpca ;
 b_flux =  0.0 * pump ;
 Dpumpca -= (f_flux - b_flux);
 Dpump += (f_flux - b_flux);
 
 /*REACTION*/
   /* pump + pumpca = TotalPump * parea * ( 1e10 ) */
 /*CONSERVATION*/
 ica_pmp = 2.0 * FARADAY * ( f_flux - b_flux ) / parea ;
 /* ~ ca [ 0 ] < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 f_flux = b_flux = 0.;
 Dca [ 0] += (b_flux =   ( - ica * PI * diam / ( 2.0 * FARADAY ) ) );
 /*FLUX*/
  {int  _li ;for ( _li = 0 ; _li <= 11 - 2 ; _li ++ ) {
   /* ~ ca [ _li ] <-> ca [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 f_flux =  DCa * _zfrat [ _li + 1 ] * ca [ _li] ;
 b_flux =  DCa * _zfrat [ _li + 1 ] * ca [ _li + 1] ;
 Dca [ _li] -= (f_flux - b_flux);
 Dca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ mg [ _li ] <-> mg [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 f_flux =  DCa * _zfrat [ _li + 1 ] * mg [ _li] ;
 b_flux =  DCa * _zfrat [ _li + 1 ] * mg [ _li + 1] ;
 Dmg [ _li] -= (f_flux - b_flux);
 Dmg [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ BTC [ _li ] <-> BTC [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 f_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC [ _li] ;
 b_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC [ _li + 1] ;
 DBTC [ _li] -= (f_flux - b_flux);
 DBTC [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ BTC_ca [ _li ] <-> BTC_ca [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 f_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC_ca [ _li] ;
 b_flux =  Dbtc * _zfrat [ _li + 1 ] * BTC_ca [ _li + 1] ;
 DBTC_ca [ _li] -= (f_flux - b_flux);
 DBTC_ca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ DMNPE [ _li ] <-> DMNPE [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 f_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE [ _li] ;
 b_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE [ _li + 1] ;
 DDMNPE [ _li] -= (f_flux - b_flux);
 DDMNPE [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ DMNPE_ca [ _li ] <-> DMNPE_ca [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 f_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE_ca [ _li] ;
 b_flux =  Ddmnpe * _zfrat [ _li + 1 ] * DMNPE_ca [ _li + 1] ;
 DDMNPE_ca [ _li] -= (f_flux - b_flux);
 DDMNPE_ca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ CB [ _li ] <-> CB [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB [ _li + 1] ;
 DCB [ _li] -= (f_flux - b_flux);
 DCB [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ CB_f_ca [ _li ] <-> CB_f_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_f_ca [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_f_ca [ _li + 1] ;
 DCB_f_ca [ _li] -= (f_flux - b_flux);
 DCB_f_ca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ CB_ca_s [ _li ] <-> CB_ca_s [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_s [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_s [ _li + 1] ;
 DCB_ca_s [ _li] -= (f_flux - b_flux);
 DCB_ca_s [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ CB_ca_ca [ _li ] <-> CB_ca_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 f_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_ca [ _li] ;
 b_flux =  Dcbd1 * _zfrat [ _li + 1 ] * CB_ca_ca [ _li + 1] ;
 DCB_ca_ca [ _li] -= (f_flux - b_flux);
 DCB_ca_ca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ PV [ _li ] <-> PV [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV [ _li + 1] ;
 DPV [ _li] -= (f_flux - b_flux);
 DPV [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ PV_ca [ _li ] <-> PV_ca [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV_ca [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV_ca [ _li + 1] ;
 DPV_ca [ _li] -= (f_flux - b_flux);
 DPV_ca [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ PV_mg [ _li ] <-> PV_mg [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 f_flux =  Dpar * _zfrat [ _li + 1 ] * PV_mg [ _li] ;
 b_flux =  Dpar * _zfrat [ _li + 1 ] * PV_mg [ _li + 1] ;
 DPV_mg [ _li] -= (f_flux - b_flux);
 DPV_mg [ _li + 1] += (f_flux - b_flux);
 
 /*REACTION*/
  } }
 _zdsq = diam * diam ;
 {int  _li ;for ( _li = 0 ; _li <= 11 - 1 ; _li ++ ) {
   _zdsqvol = _zdsq * vrat [ _li ] ;
   /* ~ ca [ _li ] + BTC [ _li ] <-> BTC_ca [ _li ] ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 f_flux =  b1 * _zdsqvol * BTC [ _li] * ca [ _li] ;
 b_flux =  b2 * _zdsqvol * BTC_ca [ _li] ;
 DBTC [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DBTC_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + DMNPE [ _li ] <-> DMNPE_ca [ _li ] ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 f_flux =  c1 * _zdsqvol * DMNPE [ _li] * ca [ _li] ;
 b_flux =  c2 * _zdsqvol * DMNPE_ca [ _li] ;
 DDMNPE [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DDMNPE_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * CB_ca_s [ _li] ;
 DCB [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DCB_ca_s [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * CB_f_ca [ _li] ;
 DCB [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DCB_f_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + CB_f_ca [ _li ] <-> CB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB_f_ca [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * CB_ca_ca [ _li] ;
 DCB_f_ca [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DCB_ca_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + CB_ca_s [ _li ] <-> CB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB_ca_s [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * CB_ca_ca [ _li] ;
 DCB_ca_s [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DCB_ca_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * iCB [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * iCB_ca_s [ _li] ;
 DiCB [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DiCB_ca_s [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * iCB [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * iCB_f_ca [ _li] ;
 DiCB [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DiCB_f_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_f_ca [ _li ] <-> iCB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * iCB_f_ca [ _li] * ca [ _li] ;
 b_flux =  nf2 * _zdsqvol * iCB_ca_ca [ _li] ;
 DiCB_f_ca [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DiCB_ca_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_ca_s [ _li ] <-> iCB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * iCB_ca_s [ _li] * ca [ _li] ;
 b_flux =  ns2 * _zdsqvol * iCB_ca_ca [ _li] ;
 DiCB_ca_s [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DiCB_ca_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca [ _li ] + PV [ _li ] <-> PV_ca [ _li ] ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 f_flux =  m1 * _zdsqvol * PV [ _li] * ca [ _li] ;
 b_flux =  m2 * _zdsqvol * PV_ca [ _li] ;
 DPV [ _li] -= (f_flux - b_flux);
 Dca [ _li] -= (f_flux - b_flux);
 DPV_ca [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ mg [ _li ] + PV [ _li ] <-> PV_mg [ _li ] ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 f_flux =  p1 * _zdsqvol * PV [ _li] * mg [ _li] ;
 b_flux =  p2 * _zdsqvol * PV_mg [ _li] ;
 DPV [ _li] -= (f_flux - b_flux);
 Dmg [ _li] -= (f_flux - b_flux);
 DPV_mg [ _li] += (f_flux - b_flux);
 
 /*REACTION*/
  } }
 cai = ca [ 0 ] ;
 mgi = mg [ 0 ] ;
 _p[_dlist1[0]] /= ( ( 1e10 ) * parea);
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 1]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 12]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 23]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 34]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 45]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 56]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 67]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 78]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 89]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 100]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 111]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 122]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 133]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 144]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 155]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 166]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 for (_i=0; _i < 11; _i++) { _p[_dlist1[_i + 177]] /= ( diam * diam * vrat [ ((int) _i ) ]);}
 _p[_dlist1[188]] /= ( ( 1e10 ) * parea);
   } return _reset;
 }
 
/*CVODE matsol*/
 static int _ode_matsol1() {_reset=0;{
 double b_flux, f_flux, _term; int _i;
   b_flux = f_flux = 0.;
 {int _i; double _dt1 = 1.0/dt;
for(_i=0;_i<189;_i++){
  	_RHS1(_i) = _dt1*(_p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
}  
_RHS1(0) *= ( ( 1e10 ) * parea) ;
_MATELM1(0, 0) *= ( ( 1e10 ) * parea); 
_RHS1(188) *= ( ( 1e10 ) * parea) ;
_MATELM1(188, 188) *= ( ( 1e10 ) * parea);  
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 1) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 1, _i + 1) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 12) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 12, _i + 12) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 23) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 23, _i + 23) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 34) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 34, _i + 34) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 45) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 45, _i + 45) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 56) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 56, _i + 56) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 67) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 67, _i + 67) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 78) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 78, _i + 78) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 89) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 89, _i + 89) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 100) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 100, _i + 100) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 111) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 111, _i + 111) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 122) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 122, _i + 122) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 133) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 133, _i + 133) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 144) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 144, _i + 144) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 155) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 155, _i + 155) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 166) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 166, _i + 166) *= ( diam * diam * vrat [ ((int) _i ) ]);  } 
for (_i=0; _i < 11; _i++) {
  	_RHS1(_i + 177) *= ( diam * diam * vrat [ ((int) _i ) ]) ;
_MATELM1(_i + 177, _i + 177) *= ( diam * diam * vrat [ ((int) _i ) ]);  } }
 /* COMPARTMENT _li , diam * diam * vrat [ ((int) _i ) ] {
 ca mg BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca iCB iCB_f_ca iCB_ca_s iCB_ca_ca PV PV_ca PV_mg }
 */
 /* COMPARTMENT ( 1e10 ) * parea {
 pump pumpca }
 */
 /* ~ ca [ 0 ] + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 _term =  kpmp1 * parea * ( 1e10 ) * ca [ 0] ;
 _MATELM1( 188 ,188)  += _term;
 _MATELM1( 122 +  0 ,188)  += _term;
 _MATELM1( 0 ,188)  -= _term;
 _term =  kpmp1 * parea * ( 1e10 ) * pump ;
 _MATELM1( 188 ,122 +  0)  += _term;
 _MATELM1( 122 +  0 ,122 +  0)  += _term;
 _MATELM1( 0 ,122 +  0)  -= _term;
 _term =  kpmp2 * parea * ( 1e10 ) ;
 _MATELM1( 188 ,0)  -= _term;
 _MATELM1( 122 +  0 ,0)  -= _term;
 _MATELM1( 0 ,0)  += _term;
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 _term =  kpmp3 * parea * ( 1e10 ) ;
 _MATELM1( 0 ,0)  += _term;
 _MATELM1( 188 ,0)  -= _term;
 _term =  0.0 ;
 _MATELM1( 0 ,188)  -= _term;
 _MATELM1( 188 ,188)  += _term;
 /* ~ ca [ 0 ] < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 /*FLUX*/
  {int  _li ;for ( _li = 0 ; _li <= 11 - 2 ; _li ++ ) {
 /* ~ ca [ _li ] <-> ca [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li + 1 ,122 +  _li)  -= _term;
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 122 +  _li ,122 +  _li + 1)  -= _term;
 _MATELM1( 122 +  _li + 1 ,122 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ mg [ _li ] <-> mg [ _li + 1 ] ( DCa * _zfrat [ _li + 1 ] , DCa * _zfrat [ _li + 1 ] )*/
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 177 +  _li ,177 +  _li)  += _term;
 _MATELM1( 177 +  _li + 1 ,177 +  _li)  -= _term;
 _term =  DCa * _zfrat [ _li + 1 ] ;
 _MATELM1( 177 +  _li ,177 +  _li + 1)  -= _term;
 _MATELM1( 177 +  _li + 1 ,177 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ BTC [ _li ] <-> BTC [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 12 +  _li ,12 +  _li)  += _term;
 _MATELM1( 12 +  _li + 1 ,12 +  _li)  -= _term;
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 12 +  _li ,12 +  _li + 1)  -= _term;
 _MATELM1( 12 +  _li + 1 ,12 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ BTC_ca [ _li ] <-> BTC_ca [ _li + 1 ] ( Dbtc * _zfrat [ _li + 1 ] , Dbtc * _zfrat [ _li + 1 ] )*/
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 1 +  _li ,1 +  _li)  += _term;
 _MATELM1( 1 +  _li + 1 ,1 +  _li)  -= _term;
 _term =  Dbtc * _zfrat [ _li + 1 ] ;
 _MATELM1( 1 +  _li ,1 +  _li + 1)  -= _term;
 _MATELM1( 1 +  _li + 1 ,1 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ DMNPE [ _li ] <-> DMNPE [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 78 +  _li ,78 +  _li)  += _term;
 _MATELM1( 78 +  _li + 1 ,78 +  _li)  -= _term;
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 78 +  _li ,78 +  _li + 1)  -= _term;
 _MATELM1( 78 +  _li + 1 ,78 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ DMNPE_ca [ _li ] <-> DMNPE_ca [ _li + 1 ] ( Ddmnpe * _zfrat [ _li + 1 ] , Ddmnpe * _zfrat [ _li + 1 ] )*/
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 67 +  _li ,67 +  _li)  += _term;
 _MATELM1( 67 +  _li + 1 ,67 +  _li)  -= _term;
 _term =  Ddmnpe * _zfrat [ _li + 1 ] ;
 _MATELM1( 67 +  _li ,67 +  _li + 1)  -= _term;
 _MATELM1( 67 +  _li + 1 ,67 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB [ _li ] <-> CB [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 56 +  _li + 1 ,56 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 56 +  _li ,56 +  _li + 1)  -= _term;
 _MATELM1( 56 +  _li + 1 ,56 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_f_ca [ _li ] <-> CB_f_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 _MATELM1( 45 +  _li + 1 ,45 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 45 +  _li ,45 +  _li + 1)  -= _term;
 _MATELM1( 45 +  _li + 1 ,45 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_ca_s [ _li ] <-> CB_ca_s [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 _MATELM1( 34 +  _li + 1 ,34 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 34 +  _li ,34 +  _li + 1)  -= _term;
 _MATELM1( 34 +  _li + 1 ,34 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ CB_ca_ca [ _li ] <-> CB_ca_ca [ _li + 1 ] ( Dcbd1 * _zfrat [ _li + 1 ] , Dcbd1 * _zfrat [ _li + 1 ] )*/
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 _MATELM1( 23 +  _li + 1 ,23 +  _li)  -= _term;
 _term =  Dcbd1 * _zfrat [ _li + 1 ] ;
 _MATELM1( 23 +  _li ,23 +  _li + 1)  -= _term;
 _MATELM1( 23 +  _li + 1 ,23 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV [ _li ] <-> PV [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 111 +  _li + 1 ,111 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 111 +  _li ,111 +  _li + 1)  -= _term;
 _MATELM1( 111 +  _li + 1 ,111 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV_ca [ _li ] <-> PV_ca [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 100 +  _li ,100 +  _li)  += _term;
 _MATELM1( 100 +  _li + 1 ,100 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 100 +  _li ,100 +  _li + 1)  -= _term;
 _MATELM1( 100 +  _li + 1 ,100 +  _li + 1)  += _term;
 /*REACTION*/
  /* ~ PV_mg [ _li ] <-> PV_mg [ _li + 1 ] ( Dpar * _zfrat [ _li + 1 ] , Dpar * _zfrat [ _li + 1 ] )*/
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 89 +  _li ,89 +  _li)  += _term;
 _MATELM1( 89 +  _li + 1 ,89 +  _li)  -= _term;
 _term =  Dpar * _zfrat [ _li + 1 ] ;
 _MATELM1( 89 +  _li ,89 +  _li + 1)  -= _term;
 _MATELM1( 89 +  _li + 1 ,89 +  _li + 1)  += _term;
 /*REACTION*/
  } }
 _zdsq = diam * diam ;
 {int  _li ;for ( _li = 0 ; _li <= 11 - 1 ; _li ++ ) {
 _zdsqvol = _zdsq * vrat [ _li ] ;
 /* ~ ca [ _li ] + BTC [ _li ] <-> BTC_ca [ _li ] ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 _term =  b1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 12 +  _li ,12 +  _li)  += _term;
 _MATELM1( 122 +  _li ,12 +  _li)  += _term;
 _MATELM1( 1 +  _li ,12 +  _li)  -= _term;
 _term =  b1 * _zdsqvol * BTC [ _li] ;
 _MATELM1( 12 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 1 +  _li ,122 +  _li)  -= _term;
 _term =  b2 * _zdsqvol ;
 _MATELM1( 12 +  _li ,1 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,1 +  _li)  -= _term;
 _MATELM1( 1 +  _li ,1 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + DMNPE [ _li ] <-> DMNPE_ca [ _li ] ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 _term =  c1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 78 +  _li ,78 +  _li)  += _term;
 _MATELM1( 122 +  _li ,78 +  _li)  += _term;
 _MATELM1( 67 +  _li ,78 +  _li)  -= _term;
 _term =  c1 * _zdsqvol * DMNPE [ _li] ;
 _MATELM1( 78 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 67 +  _li ,122 +  _li)  -= _term;
 _term =  c2 * _zdsqvol ;
 _MATELM1( 78 +  _li ,67 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,67 +  _li)  -= _term;
 _MATELM1( 67 +  _li ,67 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 122 +  _li ,56 +  _li)  += _term;
 _MATELM1( 34 +  _li ,56 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * CB [ _li] ;
 _MATELM1( 56 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 34 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 56 +  _li ,34 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,34 +  _li)  -= _term;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB [ _li ] <-> CB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 56 +  _li ,56 +  _li)  += _term;
 _MATELM1( 122 +  _li ,56 +  _li)  += _term;
 _MATELM1( 45 +  _li ,56 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * CB [ _li] ;
 _MATELM1( 56 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 45 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 56 +  _li ,45 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,45 +  _li)  -= _term;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB_f_ca [ _li ] <-> CB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 45 +  _li ,45 +  _li)  += _term;
 _MATELM1( 122 +  _li ,45 +  _li)  += _term;
 _MATELM1( 23 +  _li ,45 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * CB_f_ca [ _li] ;
 _MATELM1( 45 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 23 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 45 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + CB_ca_s [ _li ] <-> CB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 34 +  _li ,34 +  _li)  += _term;
 _MATELM1( 122 +  _li ,34 +  _li)  += _term;
 _MATELM1( 23 +  _li ,34 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * CB_ca_s [ _li] ;
 _MATELM1( 34 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 23 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 34 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,23 +  _li)  -= _term;
 _MATELM1( 23 +  _li ,23 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_ca_s [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 166 +  _li ,166 +  _li)  += _term;
 _MATELM1( 122 +  _li ,166 +  _li)  += _term;
 _MATELM1( 144 +  _li ,166 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * iCB [ _li] ;
 _MATELM1( 166 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 144 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 166 +  _li ,144 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,144 +  _li)  -= _term;
 _MATELM1( 144 +  _li ,144 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB [ _li ] <-> iCB_f_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 166 +  _li ,166 +  _li)  += _term;
 _MATELM1( 122 +  _li ,166 +  _li)  += _term;
 _MATELM1( 155 +  _li ,166 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * iCB [ _li] ;
 _MATELM1( 166 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 155 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 166 +  _li ,155 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,155 +  _li)  -= _term;
 _MATELM1( 155 +  _li ,155 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_f_ca [ _li ] <-> iCB_ca_ca [ _li ] ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 155 +  _li ,155 +  _li)  += _term;
 _MATELM1( 122 +  _li ,155 +  _li)  += _term;
 _MATELM1( 133 +  _li ,155 +  _li)  -= _term;
 _term =  nf1 * _zdsqvol * iCB_f_ca [ _li] ;
 _MATELM1( 155 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 133 +  _li ,122 +  _li)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 155 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 133 +  _li ,133 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + iCB_ca_s [ _li ] <-> iCB_ca_ca [ _li ] ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 144 +  _li ,144 +  _li)  += _term;
 _MATELM1( 122 +  _li ,144 +  _li)  += _term;
 _MATELM1( 133 +  _li ,144 +  _li)  -= _term;
 _term =  ns1 * _zdsqvol * iCB_ca_s [ _li] ;
 _MATELM1( 144 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 133 +  _li ,122 +  _li)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 144 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,133 +  _li)  -= _term;
 _MATELM1( 133 +  _li ,133 +  _li)  += _term;
 /*REACTION*/
  /* ~ ca [ _li ] + PV [ _li ] <-> PV_ca [ _li ] ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 _term =  m1 * _zdsqvol * ca [ _li] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 122 +  _li ,111 +  _li)  += _term;
 _MATELM1( 100 +  _li ,111 +  _li)  -= _term;
 _term =  m1 * _zdsqvol * PV [ _li] ;
 _MATELM1( 111 +  _li ,122 +  _li)  += _term;
 _MATELM1( 122 +  _li ,122 +  _li)  += _term;
 _MATELM1( 100 +  _li ,122 +  _li)  -= _term;
 _term =  m2 * _zdsqvol ;
 _MATELM1( 111 +  _li ,100 +  _li)  -= _term;
 _MATELM1( 122 +  _li ,100 +  _li)  -= _term;
 _MATELM1( 100 +  _li ,100 +  _li)  += _term;
 /*REACTION*/
  /* ~ mg [ _li ] + PV [ _li ] <-> PV_mg [ _li ] ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 _term =  p1 * _zdsqvol * mg [ _li] ;
 _MATELM1( 111 +  _li ,111 +  _li)  += _term;
 _MATELM1( 177 +  _li ,111 +  _li)  += _term;
 _MATELM1( 89 +  _li ,111 +  _li)  -= _term;
 _term =  p1 * _zdsqvol * PV [ _li] ;
 _MATELM1( 111 +  _li ,177 +  _li)  += _term;
 _MATELM1( 177 +  _li ,177 +  _li)  += _term;
 _MATELM1( 89 +  _li ,177 +  _li)  -= _term;
 _term =  p2 * _zdsqvol ;
 _MATELM1( 111 +  _li ,89 +  _li)  -= _term;
 _MATELM1( 177 +  _li ,89 +  _li)  -= _term;
 _MATELM1( 89 +  _li ,89 +  _li)  += _term;
 /*REACTION*/
  } }
 cai = ca [ 0 ] ;
 mgi = mg [ 0 ] ;
   } return _reset;
 }
 
/*CVODE end*/
 
static int _ode_count(int _type){ return 189;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
     _ode_spec1 ();
  _ion_cai = cai;
 }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 189; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 static void _ode_synonym(int _cnt, double** _pp, Datum** _ppd) { 
 	int _i; 
	for (_i=0; _i < _cnt; ++_i) {_p = _pp[_i]; _ppvar = _ppd[_i];
 _ion_cai =  ca [ 0 ] ;
 }}
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 _cvode_sparse(&_cvsparseobj1, 189, _dlist1, _p, _ode_matsol1, &_coef1);
 }}
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_ca_sym, _ppvar, 0, 2);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 1, 1);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 2, 3);
 }

static void initmodel() {
  int _i; double _save;_ninits++;
 _save = t;
 t = 0.0;
{
 for (_i=0; _i<11; _i++) BTC_ca[_i] = BTC_ca0;
 for (_i=0; _i<11; _i++) BTC[_i] = BTC0;
 for (_i=0; _i<11; _i++) CB_ca_ca[_i] = CB_ca_ca0;
 for (_i=0; _i<11; _i++) CB_ca_s[_i] = CB_ca_s0;
 for (_i=0; _i<11; _i++) CB_f_ca[_i] = CB_f_ca0;
 for (_i=0; _i<11; _i++) CB[_i] = CB0;
 for (_i=0; _i<11; _i++) DMNPE_ca[_i] = DMNPE_ca0;
 for (_i=0; _i<11; _i++) DMNPE[_i] = DMNPE0;
 for (_i=0; _i<11; _i++) PV_mg[_i] = PV_mg0;
 for (_i=0; _i<11; _i++) PV_ca[_i] = PV_ca0;
 for (_i=0; _i<11; _i++) PV[_i] = PV0;
 for (_i=0; _i<11; _i++) ca[_i] = ca0;
 for (_i=0; _i<11; _i++) iCB_ca_ca[_i] = iCB_ca_ca0;
 for (_i=0; _i<11; _i++) iCB_ca_s[_i] = iCB_ca_s0;
 for (_i=0; _i<11; _i++) iCB_f_ca[_i] = iCB_f_ca0;
 for (_i=0; _i<11; _i++) iCB[_i] = iCB0;
 for (_i=0; _i<11; _i++) mg[_i] = mg0;
  pumpca = pumpca0;
  pump = pump0;
 {
   if ( _zfactors_done  == 0.0 ) {
     _zfactors_done = 1.0 ;
     factors ( _threadargs_ ) ;
     }
   {int  _li ;for ( _li = 0 ; _li <= 11 - 1 ; _li ++ ) {
     ca [ _li ] = cainull ;
     mg [ _li ] = mginull ;
     BTC [ _li ] = ssBTC ( _threadargs_ ) ;
     BTC_ca [ _li ] = ssBTCca ( _threadargs_ ) ;
     DMNPE [ _li ] = ssDMNPE ( _threadargs_ ) ;
     DMNPE_ca [ _li ] = ssDMNPEca ( _threadargs_ ) ;
     CB [ _li ] = 0.8 * ssCB ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     CB_f_ca [ _li ] = 0.8 * ssCBfast ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     CB_ca_s [ _li ] = 0.8 * ssCBslow ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     CB_ca_ca [ _li ] = 0.8 * ssCBca ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     iCB [ _li ] = 0.2 * ssCB ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     iCB_f_ca [ _li ] = 0.2 * ssCBfast ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     iCB_ca_s [ _li ] = 0.2 * ssCBslow ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     iCB_ca_ca [ _li ] = 0.2 * ssCBca ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
     PV [ _li ] = ssPV ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
     PV_ca [ _li ] = ssPVca ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
     PV_mg [ _li ] = ssPVmg ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
     } }
   parea = PI * diam ;
   ica = 0.0 ;
   ica_pmp = 0.0 ;
   pump = TotalPump ;
   pumpca = 0.0 ;
   }
  _sav_indep = t; t = _save;

}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 initmodel();
  _ion_cai = cai;
  nrn_wrote_conc(_ca_sym, (&(_ion_cai)) - 1, _style_ca);
}}

static double _nrn_current(double _v){double _current=0.;v=_v;{
} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type){
 double _break, _save;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 { {
 for (; t < _break; t += dt) {
 error = sparse(&_sparseobj1, 189, _slist1, _dlist1, _p, &t, dt, state,&_coef1, _linmat1);
 if(error){fprintf(stderr,"at line 142 in file cdp3.mod:\n:	ica = ica_pmp\n"); nrn_complain(_p); abort_run(error);}
 
}}
 t = _save;
 } {
   }
  _ion_cai = cai;
}}

}

static void terminal(){}

static void _initlists() {
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(pumpca) - _p;  _dlist1[0] = &(Dpumpca) - _p;
 for(_i=0;_i<11;_i++){_slist1[1+_i] = (BTC_ca + _i) - _p;  _dlist1[1+_i] = (DBTC_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[12+_i] = (BTC + _i) - _p;  _dlist1[12+_i] = (DBTC + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[23+_i] = (CB_ca_ca + _i) - _p;  _dlist1[23+_i] = (DCB_ca_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[34+_i] = (CB_ca_s + _i) - _p;  _dlist1[34+_i] = (DCB_ca_s + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[45+_i] = (CB_f_ca + _i) - _p;  _dlist1[45+_i] = (DCB_f_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[56+_i] = (CB + _i) - _p;  _dlist1[56+_i] = (DCB + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[67+_i] = (DMNPE_ca + _i) - _p;  _dlist1[67+_i] = (DDMNPE_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[78+_i] = (DMNPE + _i) - _p;  _dlist1[78+_i] = (DDMNPE + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[89+_i] = (PV_mg + _i) - _p;  _dlist1[89+_i] = (DPV_mg + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[100+_i] = (PV_ca + _i) - _p;  _dlist1[100+_i] = (DPV_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[111+_i] = (PV + _i) - _p;  _dlist1[111+_i] = (DPV + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[122+_i] = (ca + _i) - _p;  _dlist1[122+_i] = (Dca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[133+_i] = (iCB_ca_ca + _i) - _p;  _dlist1[133+_i] = (DiCB_ca_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[144+_i] = (iCB_ca_s + _i) - _p;  _dlist1[144+_i] = (DiCB_ca_s + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[155+_i] = (iCB_f_ca + _i) - _p;  _dlist1[155+_i] = (DiCB_f_ca + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[166+_i] = (iCB + _i) - _p;  _dlist1[166+_i] = (DiCB + _i) - _p;}
 for(_i=0;_i<11;_i++){_slist1[177+_i] = (mg + _i) - _p;  _dlist1[177+_i] = (Dmg + _i) - _p;}
 _slist1[188] = &(pump) - _p;  _dlist1[188] = &(Dpump) - _p;
_first = 0;
}
