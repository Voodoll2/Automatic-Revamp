#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _CALC_ca2_DP_reg(void);
extern void _CALC_DP_reg(void);
extern void _CALC_reg(void);
extern void _CaT3_1_DP_reg(void);
extern void _CaT3_1_reg(void);
extern void _cdp3_reg(void);
extern void _cdp5_reg(void);
extern void _leak_reg(void);
extern void _mslo_DP_reg(void);
extern void _mslo_reg(void);
extern void _newCaP_DP_reg(void);
extern void _newCaP_reg(void);
extern void _SK2_DP_reg(void);
extern void _SK2_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/CALC_ca2_DP.mod");
    fprintf(stderr," mod_nsgportal/CALC_DP.mod");
    fprintf(stderr," mod_nsgportal/CALC.mod");
    fprintf(stderr," mod_nsgportal/CaT3_1_DP.mod");
    fprintf(stderr," mod_nsgportal/CaT3_1.mod");
    fprintf(stderr," mod_nsgportal/cdp3.mod");
    fprintf(stderr," mod_nsgportal/cdp5.mod");
    fprintf(stderr," mod_nsgportal/leak.mod");
    fprintf(stderr," mod_nsgportal/mslo_DP.mod");
    fprintf(stderr," mod_nsgportal/mslo.mod");
    fprintf(stderr," mod_nsgportal/newCaP_DP.mod");
    fprintf(stderr," mod_nsgportal/newCaP.mod");
    fprintf(stderr," mod_nsgportal/SK2_DP.mod");
    fprintf(stderr," mod_nsgportal/SK2.mod");
    fprintf(stderr, "\n");
  }
  _CALC_ca2_DP_reg();
  _CALC_DP_reg();
  _CALC_reg();
  _CaT3_1_DP_reg();
  _CaT3_1_reg();
  _cdp3_reg();
  _cdp5_reg();
  _leak_reg();
  _mslo_DP_reg();
  _mslo_reg();
  _newCaP_DP_reg();
  _newCaP_reg();
  _SK2_DP_reg();
  _SK2_reg();
}
