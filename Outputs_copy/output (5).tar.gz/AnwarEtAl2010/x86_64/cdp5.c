/* Created by Language version: 6.2.0 */
/* VECTORIZED */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define _threadargscomma_ _p, _ppvar, _thread, _nt,
#define _threadargs_ _p, _ppvar, _thread, _nt
 
#define _threadargsprotocomma_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt,
#define _threadargsproto_ double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 /* Thread safe. No static _p or _ppvar. */
 
#define t _nt->_t
#define dt _nt->_dt
#define Nannuli _p[0]
#define Buffnull2 _p[1]
#define rf3 _p[2]
#define rf4 _p[3]
#define ica_pmp _p[4]
#define vrat _p[5]
#define ca _p[6]
#define mg _p[7]
#define Buff1 _p[8]
#define Buff1_ca _p[9]
#define Buff2 _p[10]
#define Buff2_ca _p[11]
#define BTC _p[12]
#define BTC_ca _p[13]
#define DMNPE _p[14]
#define DMNPE_ca _p[15]
#define CB _p[16]
#define CB_f_ca _p[17]
#define CB_ca_s _p[18]
#define CB_ca_ca _p[19]
#define PV _p[20]
#define PV_ca _p[21]
#define PV_mg _p[22]
#define pump _p[23]
#define pumpca _p[24]
#define ica _p[25]
#define parea _p[26]
#define parea2 _p[27]
#define cai _p[28]
#define mgi _p[29]
#define Dca _p[30]
#define Dmg _p[31]
#define DBuff1 _p[32]
#define DBuff1_ca _p[33]
#define DBuff2 _p[34]
#define DBuff2_ca _p[35]
#define DBTC _p[36]
#define DBTC_ca _p[37]
#define DDMNPE _p[38]
#define DDMNPE_ca _p[39]
#define DCB _p[40]
#define DCB_f_ca _p[41]
#define DCB_ca_s _p[42]
#define DCB_ca_ca _p[43]
#define DPV _p[44]
#define DPV_ca _p[45]
#define DPV_mg _p[46]
#define Dpump _p[47]
#define Dpumpca _p[48]
#define v _p[49]
#define _g _p[50]
#define _ion_cao	*_ppvar[0]._pval
#define _ion_cai	*_ppvar[1]._pval
#define _ion_ica	*_ppvar[2]._pval
#define _style_ca	*((int*)_ppvar[3]._pvoid)
#define diam	*_ppvar[4]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 static Datum* _extcall_thread;
 static Prop* _extcall_prop;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_factors(void);
 static void _hoc_kdm(void);
 static void _hoc_kdc(void);
 static void _hoc_kds(void);
 static void _hoc_kdf(void);
 static void _hoc_ssPVmg(void);
 static void _hoc_ssPVca(void);
 static void _hoc_ssPV(void);
 static void _hoc_ssCBca(void);
 static void _hoc_ssCBslow(void);
 static void _hoc_ssCBfast(void);
 static void _hoc_ssCB(void);
 static void _hoc_ssDMNPEca(void);
 static void _hoc_ssDMNPE(void);
 static void _hoc_ssBTCca(void);
 static void _hoc_ssBTC(void);
 static void _hoc_ssBuff2ca(void);
 static void _hoc_ssBuff2(void);
 static void _hoc_ssBuff1ca(void);
 static void _hoc_ssBuff1(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_cdp5", _hoc_setdata,
 "factors_cdp5", _hoc_factors,
 "kdm_cdp5", _hoc_kdm,
 "kdc_cdp5", _hoc_kdc,
 "kds_cdp5", _hoc_kds,
 "kdf_cdp5", _hoc_kdf,
 "ssPVmg_cdp5", _hoc_ssPVmg,
 "ssPVca_cdp5", _hoc_ssPVca,
 "ssPV_cdp5", _hoc_ssPV,
 "ssCBca_cdp5", _hoc_ssCBca,
 "ssCBslow_cdp5", _hoc_ssCBslow,
 "ssCBfast_cdp5", _hoc_ssCBfast,
 "ssCB_cdp5", _hoc_ssCB,
 "ssDMNPEca_cdp5", _hoc_ssDMNPEca,
 "ssDMNPE_cdp5", _hoc_ssDMNPE,
 "ssBTCca_cdp5", _hoc_ssBTCca,
 "ssBTC_cdp5", _hoc_ssBTC,
 "ssBuff2ca_cdp5", _hoc_ssBuff2ca,
 "ssBuff2_cdp5", _hoc_ssBuff2,
 "ssBuff1ca_cdp5", _hoc_ssBuff1ca,
 "ssBuff1_cdp5", _hoc_ssBuff1,
 0, 0
};
#define kdm kdm_cdp5
#define kdc kdc_cdp5
#define kds kds_cdp5
#define kdf kdf_cdp5
#define ssPVmg ssPVmg_cdp5
#define ssPVca ssPVca_cdp5
#define ssPV ssPV_cdp5
#define ssCBca ssCBca_cdp5
#define ssCBslow ssCBslow_cdp5
#define ssCBfast ssCBfast_cdp5
#define ssCB ssCB_cdp5
#define ssDMNPEca ssDMNPEca_cdp5
#define ssDMNPE ssDMNPE_cdp5
#define ssBTCca ssBTCca_cdp5
#define ssBTC ssBTC_cdp5
#define ssBuff2ca ssBuff2ca_cdp5
#define ssBuff2 ssBuff2_cdp5
#define ssBuff1ca ssBuff1ca_cdp5
#define ssBuff1 ssBuff1_cdp5
 extern double kdm( _threadargsproto_ );
 extern double kdc( _threadargsproto_ );
 extern double kds( _threadargsproto_ );
 extern double kdf( _threadargsproto_ );
 extern double ssPVmg( _threadargsprotocomma_ double , double );
 extern double ssPVca( _threadargsprotocomma_ double , double );
 extern double ssPV( _threadargsprotocomma_ double , double );
 extern double ssCBca( _threadargsprotocomma_ double , double );
 extern double ssCBslow( _threadargsprotocomma_ double , double );
 extern double ssCBfast( _threadargsprotocomma_ double , double );
 extern double ssCB( _threadargsprotocomma_ double , double );
 extern double ssDMNPEca( _threadargsproto_ );
 extern double ssDMNPE( _threadargsproto_ );
 extern double ssBTCca( _threadargsproto_ );
 extern double ssBTC( _threadargsproto_ );
 extern double ssBuff2ca( _threadargsproto_ );
 extern double ssBuff2( _threadargsproto_ );
 extern double ssBuff1ca( _threadargsproto_ );
 extern double ssBuff1( _threadargsproto_ );
 #define _zfactors_done _thread[2]._pval[0]
 #define _zdsq _thread[2]._pval[1]
 #define _zdsqvol _thread[2]._pval[2]
 /* declare global and static user variables */
#define BTCnull BTCnull_cdp5
 double BTCnull = 0;
#define Buffnull1 Buffnull1_cdp5
 double Buffnull1 = 0;
#define CBnull CBnull_cdp5
 double CBnull = 0.16;
#define DMNPEnull DMNPEnull_cdp5
 double DMNPEnull = 0;
#define PVnull PVnull_cdp5
 double PVnull = 0.08;
#define TotalPump TotalPump_cdp5
 double TotalPump = 1e-09;
#define b2 b2_cdp5
 double b2 = 0.08;
#define b1 b1_cdp5
 double b1 = 5.33;
#define c2 c2_cdp5
 double c2 = 0.000107;
#define c1 c1_cdp5
 double c1 = 5.63;
#define cainull cainull_cdp5
 double cainull = 4.5e-05;
#define kpmp3 kpmp3_cdp5
 double kpmp3 = 7.255e-05;
#define kpmp2 kpmp2_cdp5
 double kpmp2 = 1.75e-05;
#define kpmp1 kpmp1_cdp5
 double kpmp1 = 0.003;
#define m2 m2_cdp5
 double m2 = 0.00095;
#define m1 m1_cdp5
 double m1 = 107;
#define mginull mginull_cdp5
 double mginull = 0.59;
#define ns2 ns2_cdp5
 double ns2 = 0.0026;
#define ns1 ns1_cdp5
 double ns1 = 5.5;
#define nf2 nf2_cdp5
 double nf2 = 0.0358;
#define nf1 nf1_cdp5
 double nf1 = 43.5;
#define p2 p2_cdp5
 double p2 = 0.025;
#define p1 p1_cdp5
 double p1 = 0.8;
#define rf2 rf2_cdp5
 double rf2 = 0.0397469;
#define rf1 rf1_cdp5
 double rf1 = 0.0134329;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "cainull_cdp5", "mM",
 "mginull_cdp5", "mM",
 "Buffnull1_cdp5", "mM",
 "rf1_cdp5", "/ms",
 "rf2_cdp5", "/ms",
 "BTCnull_cdp5", "mM",
 "b1_cdp5", "/ms",
 "b2_cdp5", "/ms",
 "DMNPEnull_cdp5", "mM",
 "c1_cdp5", "/ms",
 "c2_cdp5", "/ms",
 "CBnull_cdp5", "mM",
 "nf1_cdp5", "/ms",
 "nf2_cdp5", "/ms",
 "ns1_cdp5", "/ms",
 "ns2_cdp5", "/ms",
 "PVnull_cdp5", "mM",
 "m1_cdp5", "/ms",
 "m2_cdp5", "/ms",
 "p1_cdp5", "/ms",
 "p2_cdp5", "/ms",
 "kpmp1_cdp5", "/mM-ms",
 "kpmp2_cdp5", "/ms",
 "kpmp3_cdp5", "/ms",
 "TotalPump_cdp5", "mol/cm2",
 "Nannuli_cdp5", "1",
 "Buffnull2_cdp5", "mM",
 "rf3_cdp5", "/ms",
 "rf4_cdp5", "/ms",
 "ca_cdp5", "mM",
 "mg_cdp5", "mM",
 "Buff1_cdp5", "mM",
 "Buff1_ca_cdp5", "mM",
 "Buff2_cdp5", "mM",
 "Buff2_ca_cdp5", "mM",
 "BTC_cdp5", "mM",
 "BTC_ca_cdp5", "mM",
 "DMNPE_cdp5", "mM",
 "DMNPE_ca_cdp5", "mM",
 "CB_cdp5", "mM",
 "CB_f_ca_cdp5", "mM",
 "CB_ca_s_cdp5", "mM",
 "CB_ca_ca_cdp5", "mM",
 "PV_cdp5", "mM",
 "PV_ca_cdp5", "mM",
 "PV_mg_cdp5", "mM",
 "pump_cdp5", "mol/cm2",
 "pumpca_cdp5", "mol/cm2",
 "ica_pmp_cdp5", "mA/cm2",
 "vrat_cdp5", "1",
 0,0
};
 static double BTC_ca0 = 0;
 static double BTC0 = 0;
 static double Buff2_ca0 = 0;
 static double Buff20 = 0;
 static double Buff1_ca0 = 0;
 static double Buff10 = 0;
 static double CB_ca_ca0 = 0;
 static double CB_ca_s0 = 0;
 static double CB_f_ca0 = 0;
 static double CB0 = 0;
 static double DMNPE_ca0 = 0;
 static double DMNPE0 = 0;
 static double PV_mg0 = 0;
 static double PV_ca0 = 0;
 static double PV0 = 0;
 static double ca0 = 0;
 static double delta_t = 0.01;
 static double mg0 = 0;
 static double pumpca0 = 0;
 static double pump0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "cainull_cdp5", &cainull_cdp5,
 "mginull_cdp5", &mginull_cdp5,
 "Buffnull1_cdp5", &Buffnull1_cdp5,
 "rf1_cdp5", &rf1_cdp5,
 "rf2_cdp5", &rf2_cdp5,
 "BTCnull_cdp5", &BTCnull_cdp5,
 "b1_cdp5", &b1_cdp5,
 "b2_cdp5", &b2_cdp5,
 "DMNPEnull_cdp5", &DMNPEnull_cdp5,
 "c1_cdp5", &c1_cdp5,
 "c2_cdp5", &c2_cdp5,
 "CBnull_cdp5", &CBnull_cdp5,
 "nf1_cdp5", &nf1_cdp5,
 "nf2_cdp5", &nf2_cdp5,
 "ns1_cdp5", &ns1_cdp5,
 "ns2_cdp5", &ns2_cdp5,
 "PVnull_cdp5", &PVnull_cdp5,
 "m1_cdp5", &m1_cdp5,
 "m2_cdp5", &m2_cdp5,
 "p1_cdp5", &p1_cdp5,
 "p2_cdp5", &p2_cdp5,
 "kpmp1_cdp5", &kpmp1_cdp5,
 "kpmp2_cdp5", &kpmp2_cdp5,
 "kpmp3_cdp5", &kpmp3_cdp5,
 "TotalPump_cdp5", &TotalPump_cdp5,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[5]._i
 static void _ode_synonym(int, double**, Datum**);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "6.2.0",
"cdp5",
 "Nannuli_cdp5",
 "Buffnull2_cdp5",
 "rf3_cdp5",
 "rf4_cdp5",
 0,
 "ica_pmp_cdp5",
 "vrat_cdp5",
 0,
 "ca_cdp5",
 "mg_cdp5",
 "Buff1_cdp5",
 "Buff1_ca_cdp5",
 "Buff2_cdp5",
 "Buff2_ca_cdp5",
 "BTC_cdp5",
 "BTC_ca_cdp5",
 "DMNPE_cdp5",
 "DMNPE_ca_cdp5",
 "CB_cdp5",
 "CB_f_ca_cdp5",
 "CB_ca_s_cdp5",
 "CB_ca_ca_cdp5",
 "PV_cdp5",
 "PV_ca_cdp5",
 "PV_mg_cdp5",
 "pump_cdp5",
 "pumpca_cdp5",
 0,
 0};
 static Symbol* _morphology_sym;
 static Symbol* _ca_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 51, _prop);
 	/*initialize range parameters*/
 	Nannuli = 10.9495;
 	Buffnull2 = 60.9091;
 	rf3 = 0.1435;
 	rf4 = 0.0014;
 	_prop->param = _p;
 	_prop->param_size = 51;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 6, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_morphology_sym);
 	_ppvar[4]._pval = &prop_ion->param[0]; /* diam */
 prop_ion = need_memb(_ca_sym);
 nrn_check_conc_write(_prop, prop_ion, 1);
 nrn_promote(prop_ion, 3, 0);
 	_ppvar[0]._pval = &prop_ion->param[2]; /* cao */
 	_ppvar[1]._pval = &prop_ion->param[1]; /* cai */
 	_ppvar[2]._pval = &prop_ion->param[3]; /* ica */
 	_ppvar[3]._pvoid = (void*)(&(prop_ion->dparam[0]._i)); /* iontype for ca */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 "mg_cdp5", 1e-07,
 "pump_cdp5", 1e-15,
 "pumpca_cdp5", 1e-15,
 0,0
};
 static void _thread_mem_init(Datum*);
 static void _thread_cleanup(Datum*);
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*f)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _cdp5_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("ca", -10000.);
 	_morphology_sym = hoc_lookup("morphology");
 	_ca_sym = hoc_lookup("ca_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 4);
  _extcall_thread = (Datum*)ecalloc(3, sizeof(Datum));
  _thread_mem_init(_extcall_thread);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 1, _thread_mem_init);
     _nrn_thread_reg(_mechtype, 0, _thread_cleanup);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
  hoc_register_prop_size(_mechtype, 51, 6);
 	nrn_writes_conc(_mechtype, 0);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_synonym(_mechtype, _ode_synonym);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 cdp5 /projects/ps-nsg/home/nsguser/ngbw/workspace/NGBW-JOB-NEURON73_TG-2B2850FE62F34CB5983E3139C46F808C/AnwarEtAl2010/x86_64/cdp5.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double FARADAY = 9.64853;
 static double PI = 3.14159;
 static double cao = 2;
 /*Top LOCAL _zfactors_done */
 /*Top LOCAL _zdsq , _zdsqvol */
static int _reset;
static char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int factors(_threadargsproto_);
 extern double *_nrn_thread_getelm();
 
#define _MATELM1(_row,_col) *(_nrn_thread_getelm(_so, _row + 1, _col + 1))
 
#define _RHS1(_arg) _rhs[_arg+1]
  
#define _linmat1  0
 static int _spth1 = 1;
 static int _cvspth1 = 0;
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static int _slist1[19], _dlist1[19]; static double *_temp1;
 static int state();
 
static int  factors ( _threadargsproto_ ) {
   double _lr , _ldr2 ;
 _lr = 1.0 / 2.0 ;
   _ldr2 = _lr / ( Nannuli - 1.0 ) / 2.0 ;
   vrat = PI * ( _lr - _ldr2 / 2.0 ) * 2.0 * _ldr2 ;
   _lr = _lr - _ldr2 ;
    return 0; }
 
static void _hoc_factors(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r = 1.;
 factors ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
static int state (void* _so, double* _rhs, double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt)
 {int _reset=0;
 {
   double b_flux, f_flux, _term; int _i;
 {int _i; double _dt1 = 1.0/dt;
for(_i=1;_i<19;_i++){
  	_RHS1(_i) = -_dt1*(_p[_slist1[_i]] - _p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
}  
_RHS1(1) *= ( diam * diam * vrat) ;
_MATELM1(1, 1) *= ( diam * diam * vrat); 
_RHS1(2) *= ( diam * diam * vrat) ;
_MATELM1(2, 2) *= ( diam * diam * vrat); 
_RHS1(3) *= ( diam * diam * vrat) ;
_MATELM1(3, 3) *= ( diam * diam * vrat); 
_RHS1(4) *= ( diam * diam * vrat) ;
_MATELM1(4, 4) *= ( diam * diam * vrat); 
_RHS1(5) *= ( diam * diam * vrat) ;
_MATELM1(5, 5) *= ( diam * diam * vrat); 
_RHS1(6) *= ( diam * diam * vrat) ;
_MATELM1(6, 6) *= ( diam * diam * vrat); 
_RHS1(7) *= ( diam * diam * vrat) ;
_MATELM1(7, 7) *= ( diam * diam * vrat); 
_RHS1(8) *= ( diam * diam * vrat) ;
_MATELM1(8, 8) *= ( diam * diam * vrat); 
_RHS1(9) *= ( diam * diam * vrat) ;
_MATELM1(9, 9) *= ( diam * diam * vrat); 
_RHS1(10) *= ( diam * diam * vrat) ;
_MATELM1(10, 10) *= ( diam * diam * vrat); 
_RHS1(11) *= ( diam * diam * vrat) ;
_MATELM1(11, 11) *= ( diam * diam * vrat); 
_RHS1(12) *= ( diam * diam * vrat) ;
_MATELM1(12, 12) *= ( diam * diam * vrat); 
_RHS1(13) *= ( diam * diam * vrat) ;
_MATELM1(13, 13) *= ( diam * diam * vrat); 
_RHS1(14) *= ( diam * diam * vrat) ;
_MATELM1(14, 14) *= ( diam * diam * vrat); 
_RHS1(15) *= ( diam * diam * vrat) ;
_MATELM1(15, 15) *= ( diam * diam * vrat); 
_RHS1(16) *= ( diam * diam * vrat) ;
_MATELM1(16, 16) *= ( diam * diam * vrat); 
_RHS1(17) *= ( diam * diam * vrat) ;
_MATELM1(17, 17) *= ( diam * diam * vrat); 
_RHS1(18) *= ( ( 1e10 ) * parea) ;
_MATELM1(18, 18) *= ( ( 1e10 ) * parea);  }
 /* COMPARTMENT diam * diam * vrat {
     ca mg Buff1 Buff1_ca Buff2 Buff2_ca BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca PV PV_ca PV_mg }
   */
 /* COMPARTMENT ( 1e10 ) * parea {
     pump pumpca }
   */
 /* ~ ca + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 f_flux =  kpmp1 * parea * ( 1e10 ) * pump * ca ;
 b_flux =  kpmp2 * parea * ( 1e10 ) * pumpca ;
 _RHS1( 18) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 
 _term =  kpmp1 * parea * ( 1e10 ) * ca ;
 _MATELM1( 18 ,18)  += _term;
 _MATELM1( 16 ,18)  += _term;
 _term =  kpmp1 * parea * ( 1e10 ) * pump ;
 _MATELM1( 18 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _term =  kpmp2 * parea * ( 1e10 ) ;
 _MATELM1( 18 ,0)  -= _term;
 _MATELM1( 16 ,0)  -= _term;
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 f_flux =  kpmp3 * parea * ( 1e10 ) * pumpca ;
 b_flux =  0.0 * pump ;
 _RHS1( 18) += (f_flux - b_flux);
 
 _term =  kpmp3 * parea * ( 1e10 ) ;
 _MATELM1( 18 ,0)  -= _term;
 _term =  0.0 ;
 _MATELM1( 18 ,18)  += _term;
 /*REACTION*/
   /* pump + pumpca = TotalPump * parea * ( 1e10 ) */
 _RHS1(0) =  TotalPump * parea * ( 1e10 );
 _MATELM1(0, 0) = 1 * ( ( 1e10 ) * parea);
 _RHS1(0) -= pumpca * ( ( 1e10 ) * parea) ;
 _MATELM1(0, 18) = 1 * ( ( 1e10 ) * parea);
 _RHS1(0) -= pump * ( ( 1e10 ) * parea) ;
 /*CONSERVATION*/
 ica_pmp = 2.0 * FARADAY * ( f_flux - b_flux ) / parea ;
   /* ~ ca < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 f_flux = b_flux = 0.;
 _RHS1( 16) += (b_flux =   ( - ica * PI * diam / ( 2.0 * FARADAY ) ) );
 /*FLUX*/
  _zdsq = diam * diam ;
   _zdsqvol = _zdsq * vrat ;
   /* ~ ca + Buff1 <-> Buff1_ca ( rf1 * _zdsqvol , rf2 * _zdsqvol )*/
 f_flux =  rf1 * _zdsqvol * Buff1 * ca ;
 b_flux =  rf2 * _zdsqvol * Buff1_ca ;
 _RHS1( 6) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 5) += (f_flux - b_flux);
 
 _term =  rf1 * _zdsqvol * ca ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 16 ,6)  += _term;
 _MATELM1( 5 ,6)  -= _term;
 _term =  rf1 * _zdsqvol * Buff1 ;
 _MATELM1( 6 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 5 ,16)  -= _term;
 _term =  rf2 * _zdsqvol ;
 _MATELM1( 6 ,5)  -= _term;
 _MATELM1( 16 ,5)  -= _term;
 _MATELM1( 5 ,5)  += _term;
 /*REACTION*/
  /* ~ ca + Buff2 <-> Buff2_ca ( rf3 * _zdsqvol , rf4 * _zdsqvol )*/
 f_flux =  rf3 * _zdsqvol * Buff2 * ca ;
 b_flux =  rf4 * _zdsqvol * Buff2_ca ;
 _RHS1( 4) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 3) += (f_flux - b_flux);
 
 _term =  rf3 * _zdsqvol * ca ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 16 ,4)  += _term;
 _MATELM1( 3 ,4)  -= _term;
 _term =  rf3 * _zdsqvol * Buff2 ;
 _MATELM1( 4 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 3 ,16)  -= _term;
 _term =  rf4 * _zdsqvol ;
 _MATELM1( 4 ,3)  -= _term;
 _MATELM1( 16 ,3)  -= _term;
 _MATELM1( 3 ,3)  += _term;
 /*REACTION*/
  /* ~ ca + BTC <-> BTC_ca ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 f_flux =  b1 * _zdsqvol * BTC * ca ;
 b_flux =  b2 * _zdsqvol * BTC_ca ;
 _RHS1( 2) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 1) += (f_flux - b_flux);
 
 _term =  b1 * _zdsqvol * ca ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 16 ,2)  += _term;
 _MATELM1( 1 ,2)  -= _term;
 _term =  b1 * _zdsqvol * BTC ;
 _MATELM1( 2 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 1 ,16)  -= _term;
 _term =  b2 * _zdsqvol ;
 _MATELM1( 2 ,1)  -= _term;
 _MATELM1( 16 ,1)  -= _term;
 _MATELM1( 1 ,1)  += _term;
 /*REACTION*/
  /* ~ ca + DMNPE <-> DMNPE_ca ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 f_flux =  c1 * _zdsqvol * DMNPE * ca ;
 b_flux =  c2 * _zdsqvol * DMNPE_ca ;
 _RHS1( 12) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 11) += (f_flux - b_flux);
 
 _term =  c1 * _zdsqvol * ca ;
 _MATELM1( 12 ,12)  += _term;
 _MATELM1( 16 ,12)  += _term;
 _MATELM1( 11 ,12)  -= _term;
 _term =  c1 * _zdsqvol * DMNPE ;
 _MATELM1( 12 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 11 ,16)  -= _term;
 _term =  c2 * _zdsqvol ;
 _MATELM1( 12 ,11)  -= _term;
 _MATELM1( 16 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ ca + CB <-> CB_ca_s ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB * ca ;
 b_flux =  nf2 * _zdsqvol * CB_ca_s ;
 _RHS1( 10) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 8) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 16 ,10)  += _term;
 _MATELM1( 8 ,10)  -= _term;
 _term =  nf1 * _zdsqvol * CB ;
 _MATELM1( 10 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 8 ,16)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 10 ,8)  -= _term;
 _MATELM1( 16 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ ca + CB <-> CB_f_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB * ca ;
 b_flux =  ns2 * _zdsqvol * CB_f_ca ;
 _RHS1( 10) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 9) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 16 ,10)  += _term;
 _MATELM1( 9 ,10)  -= _term;
 _term =  ns1 * _zdsqvol * CB ;
 _MATELM1( 10 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 9 ,16)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 10 ,9)  -= _term;
 _MATELM1( 16 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ ca + CB_f_ca <-> CB_ca_ca ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB_f_ca * ca ;
 b_flux =  nf2 * _zdsqvol * CB_ca_ca ;
 _RHS1( 9) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 7) += (f_flux - b_flux);
 
 _term =  nf1 * _zdsqvol * ca ;
 _MATELM1( 9 ,9)  += _term;
 _MATELM1( 16 ,9)  += _term;
 _MATELM1( 7 ,9)  -= _term;
 _term =  nf1 * _zdsqvol * CB_f_ca ;
 _MATELM1( 9 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 7 ,16)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 9 ,7)  -= _term;
 _MATELM1( 16 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ ca + CB_ca_s <-> CB_ca_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB_ca_s * ca ;
 b_flux =  ns2 * _zdsqvol * CB_ca_ca ;
 _RHS1( 8) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 7) += (f_flux - b_flux);
 
 _term =  ns1 * _zdsqvol * ca ;
 _MATELM1( 8 ,8)  += _term;
 _MATELM1( 16 ,8)  += _term;
 _MATELM1( 7 ,8)  -= _term;
 _term =  ns1 * _zdsqvol * CB_ca_s ;
 _MATELM1( 8 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 7 ,16)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 8 ,7)  -= _term;
 _MATELM1( 16 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ ca + PV <-> PV_ca ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 f_flux =  m1 * _zdsqvol * PV * ca ;
 b_flux =  m2 * _zdsqvol * PV_ca ;
 _RHS1( 15) -= (f_flux - b_flux);
 _RHS1( 16) -= (f_flux - b_flux);
 _RHS1( 14) += (f_flux - b_flux);
 
 _term =  m1 * _zdsqvol * ca ;
 _MATELM1( 15 ,15)  += _term;
 _MATELM1( 16 ,15)  += _term;
 _MATELM1( 14 ,15)  -= _term;
 _term =  m1 * _zdsqvol * PV ;
 _MATELM1( 15 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 14 ,16)  -= _term;
 _term =  m2 * _zdsqvol ;
 _MATELM1( 15 ,14)  -= _term;
 _MATELM1( 16 ,14)  -= _term;
 _MATELM1( 14 ,14)  += _term;
 /*REACTION*/
  /* ~ mg + PV <-> PV_mg ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 f_flux =  p1 * _zdsqvol * PV * mg ;
 b_flux =  p2 * _zdsqvol * PV_mg ;
 _RHS1( 15) -= (f_flux - b_flux);
 _RHS1( 17) -= (f_flux - b_flux);
 _RHS1( 13) += (f_flux - b_flux);
 
 _term =  p1 * _zdsqvol * mg ;
 _MATELM1( 15 ,15)  += _term;
 _MATELM1( 17 ,15)  += _term;
 _MATELM1( 13 ,15)  -= _term;
 _term =  p1 * _zdsqvol * PV ;
 _MATELM1( 15 ,17)  += _term;
 _MATELM1( 17 ,17)  += _term;
 _MATELM1( 13 ,17)  -= _term;
 _term =  p2 * _zdsqvol ;
 _MATELM1( 15 ,13)  -= _term;
 _MATELM1( 17 ,13)  -= _term;
 _MATELM1( 13 ,13)  += _term;
 /*REACTION*/
  cai = ca ;
   mgi = mg ;
     } return _reset;
 }
 
double ssBuff1 ( _threadargsproto_ ) {
   double _lssBuff1;
 _lssBuff1 = Buffnull1 / ( 1.0 + ( ( rf1 / rf2 ) * cainull ) ) ;
   
return _lssBuff1;
 }
 
static void _hoc_ssBuff1(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBuff1 ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssBuff1ca ( _threadargsproto_ ) {
   double _lssBuff1ca;
 _lssBuff1ca = Buffnull1 / ( 1.0 + ( rf2 / ( rf1 * cainull ) ) ) ;
   
return _lssBuff1ca;
 }
 
static void _hoc_ssBuff1ca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBuff1ca ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssBuff2 ( _threadargsproto_ ) {
   double _lssBuff2;
 _lssBuff2 = Buffnull2 / ( 1.0 + ( ( rf3 / rf4 ) * cainull ) ) ;
   
return _lssBuff2;
 }
 
static void _hoc_ssBuff2(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBuff2 ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssBuff2ca ( _threadargsproto_ ) {
   double _lssBuff2ca;
 _lssBuff2ca = Buffnull2 / ( 1.0 + ( rf4 / ( rf3 * cainull ) ) ) ;
   
return _lssBuff2ca;
 }
 
static void _hoc_ssBuff2ca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBuff2ca ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssBTC ( _threadargsproto_ ) {
   double _lssBTC;
 _lssBTC = BTCnull / ( 1.0 + ( ( b1 / b2 ) * cainull ) ) ;
   
return _lssBTC;
 }
 
static void _hoc_ssBTC(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBTC ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssBTCca ( _threadargsproto_ ) {
   double _lssBTCca;
 _lssBTCca = BTCnull / ( 1.0 + ( b2 / ( b1 * cainull ) ) ) ;
   
return _lssBTCca;
 }
 
static void _hoc_ssBTCca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssBTCca ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssDMNPE ( _threadargsproto_ ) {
   double _lssDMNPE;
 _lssDMNPE = DMNPEnull / ( 1.0 + ( ( c1 / c2 ) * cainull ) ) ;
   
return _lssDMNPE;
 }
 
static void _hoc_ssDMNPE(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssDMNPE ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssDMNPEca ( _threadargsproto_ ) {
   double _lssDMNPEca;
 _lssDMNPEca = DMNPEnull / ( 1.0 + ( c2 / ( c1 * cainull ) ) ) ;
   
return _lssDMNPEca;
 }
 
static void _hoc_ssDMNPEca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssDMNPEca ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssCB ( _threadargsprotocomma_ double _lkdf , double _lkds ) {
   double _lssCB;
 _lssCB = CBnull / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCB;
 }
 
static void _hoc_ssCB(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssCB ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBfast ( _threadargsprotocomma_ double _lkdf , double _lkds ) {
   double _lssCBfast;
 _lssCBfast = ( CBnull * kds ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBfast;
 }
 
static void _hoc_ssCBfast(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssCBfast ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBslow ( _threadargsprotocomma_ double _lkdf , double _lkds ) {
   double _lssCBslow;
 _lssCBslow = ( CBnull * kdf ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBslow;
 }
 
static void _hoc_ssCBslow(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssCBslow ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssCBca ( _threadargsprotocomma_ double _lkdf , double _lkds ) {
   double _lssCBca;
 _lssCBca = ( CBnull * kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) / ( 1.0 + kdf ( _threadargs_ ) + kds ( _threadargs_ ) + ( kdf ( _threadargs_ ) * kds ( _threadargs_ ) ) ) ;
   
return _lssCBca;
 }
 
static void _hoc_ssCBca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssCBca ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double kdf ( _threadargsproto_ ) {
   double _lkdf;
 _lkdf = ( cainull * nf1 ) / nf2 ;
   
return _lkdf;
 }
 
static void _hoc_kdf(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  kdf ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double kds ( _threadargsproto_ ) {
   double _lkds;
 _lkds = ( cainull * ns1 ) / ns2 ;
   
return _lkds;
 }
 
static void _hoc_kds(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  kds ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double kdc ( _threadargsproto_ ) {
   double _lkdc;
 _lkdc = ( cainull * m1 ) / m2 ;
   
return _lkdc;
 }
 
static void _hoc_kdc(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  kdc ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double kdm ( _threadargsproto_ ) {
   double _lkdm;
 _lkdm = ( mginull * p1 ) / p2 ;
   
return _lkdm;
 }
 
static void _hoc_kdm(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  kdm ( _p, _ppvar, _thread, _nt );
 hoc_retpushx(_r);
}
 
double ssPV ( _threadargsprotocomma_ double _lkdc , double _lkdm ) {
   double _lssPV;
 _lssPV = PVnull / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPV;
 }
 
static void _hoc_ssPV(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssPV ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssPVca ( _threadargsprotocomma_ double _lkdc , double _lkdm ) {
   double _lssPVca;
 _lssPVca = ( PVnull * kdc ( _threadargs_ ) ) / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPVca;
 }
 
static void _hoc_ssPVca(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssPVca ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
double ssPVmg ( _threadargsprotocomma_ double _lkdc , double _lkdm ) {
   double _lssPVmg;
 _lssPVmg = ( PVnull * kdm ( _threadargs_ ) ) / ( 1.0 + kdc ( _threadargs_ ) + kdm ( _threadargs_ ) ) ;
   
return _lssPVmg;
 }
 
static void _hoc_ssPVmg(void) {
  double _r;
   double* _p; Datum* _ppvar; Datum* _thread; _NrnThread* _nt;
   if (_extcall_prop) {_p = _extcall_prop->param; _ppvar = _extcall_prop->dparam;}else{ _p = (double*)0; _ppvar = (Datum*)0; }
  _thread = _extcall_thread;
  _nt = nrn_threads;
 _r =  ssPVmg ( _p, _ppvar, _thread, _nt, *getarg(1) , *getarg(2) );
 hoc_retpushx(_r);
}
 
/*CVODE ode begin*/
 static int _ode_spec1(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset=0;{
 double b_flux, f_flux, _term; int _i;
 {int _i; for(_i=0;_i<19;_i++) _p[_dlist1[_i]] = 0.0;}
 /* COMPARTMENT diam * diam * vrat {
   ca mg Buff1 Buff1_ca Buff2 Buff2_ca BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca PV PV_ca PV_mg }
 */
 /* COMPARTMENT ( 1e10 ) * parea {
   pump pumpca }
 */
 /* ~ ca + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 f_flux =  kpmp1 * parea * ( 1e10 ) * pump * ca ;
 b_flux =  kpmp2 * parea * ( 1e10 ) * pumpca ;
 Dpump -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 Dpumpca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 f_flux =  kpmp3 * parea * ( 1e10 ) * pumpca ;
 b_flux =  0.0 * pump ;
 Dpumpca -= (f_flux - b_flux);
 Dpump += (f_flux - b_flux);
 
 /*REACTION*/
   /* pump + pumpca = TotalPump * parea * ( 1e10 ) */
 /*CONSERVATION*/
 ica_pmp = 2.0 * FARADAY * ( f_flux - b_flux ) / parea ;
 /* ~ ca < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 f_flux = b_flux = 0.;
 Dca += (b_flux =   ( - ica * PI * diam / ( 2.0 * FARADAY ) ) );
 /*FLUX*/
  _zdsq = diam * diam ;
 _zdsqvol = _zdsq * vrat ;
 /* ~ ca + Buff1 <-> Buff1_ca ( rf1 * _zdsqvol , rf2 * _zdsqvol )*/
 f_flux =  rf1 * _zdsqvol * Buff1 * ca ;
 b_flux =  rf2 * _zdsqvol * Buff1_ca ;
 DBuff1 -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DBuff1_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + Buff2 <-> Buff2_ca ( rf3 * _zdsqvol , rf4 * _zdsqvol )*/
 f_flux =  rf3 * _zdsqvol * Buff2 * ca ;
 b_flux =  rf4 * _zdsqvol * Buff2_ca ;
 DBuff2 -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DBuff2_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + BTC <-> BTC_ca ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 f_flux =  b1 * _zdsqvol * BTC * ca ;
 b_flux =  b2 * _zdsqvol * BTC_ca ;
 DBTC -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DBTC_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + DMNPE <-> DMNPE_ca ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 f_flux =  c1 * _zdsqvol * DMNPE * ca ;
 b_flux =  c2 * _zdsqvol * DMNPE_ca ;
 DDMNPE -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DDMNPE_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + CB <-> CB_ca_s ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB * ca ;
 b_flux =  nf2 * _zdsqvol * CB_ca_s ;
 DCB -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DCB_ca_s += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + CB <-> CB_f_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB * ca ;
 b_flux =  ns2 * _zdsqvol * CB_f_ca ;
 DCB -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DCB_f_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + CB_f_ca <-> CB_ca_ca ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 f_flux =  nf1 * _zdsqvol * CB_f_ca * ca ;
 b_flux =  nf2 * _zdsqvol * CB_ca_ca ;
 DCB_f_ca -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DCB_ca_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + CB_ca_s <-> CB_ca_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 f_flux =  ns1 * _zdsqvol * CB_ca_s * ca ;
 b_flux =  ns2 * _zdsqvol * CB_ca_ca ;
 DCB_ca_s -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DCB_ca_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ ca + PV <-> PV_ca ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 f_flux =  m1 * _zdsqvol * PV * ca ;
 b_flux =  m2 * _zdsqvol * PV_ca ;
 DPV -= (f_flux - b_flux);
 Dca -= (f_flux - b_flux);
 DPV_ca += (f_flux - b_flux);
 
 /*REACTION*/
  /* ~ mg + PV <-> PV_mg ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 f_flux =  p1 * _zdsqvol * PV * mg ;
 b_flux =  p2 * _zdsqvol * PV_mg ;
 DPV -= (f_flux - b_flux);
 Dmg -= (f_flux - b_flux);
 DPV_mg += (f_flux - b_flux);
 
 /*REACTION*/
  cai = ca ;
 mgi = mg ;
 _p[_dlist1[0]] /= ( ( 1e10 ) * parea);
 _p[_dlist1[1]] /= ( diam * diam * vrat);
 _p[_dlist1[2]] /= ( diam * diam * vrat);
 _p[_dlist1[3]] /= ( diam * diam * vrat);
 _p[_dlist1[4]] /= ( diam * diam * vrat);
 _p[_dlist1[5]] /= ( diam * diam * vrat);
 _p[_dlist1[6]] /= ( diam * diam * vrat);
 _p[_dlist1[7]] /= ( diam * diam * vrat);
 _p[_dlist1[8]] /= ( diam * diam * vrat);
 _p[_dlist1[9]] /= ( diam * diam * vrat);
 _p[_dlist1[10]] /= ( diam * diam * vrat);
 _p[_dlist1[11]] /= ( diam * diam * vrat);
 _p[_dlist1[12]] /= ( diam * diam * vrat);
 _p[_dlist1[13]] /= ( diam * diam * vrat);
 _p[_dlist1[14]] /= ( diam * diam * vrat);
 _p[_dlist1[15]] /= ( diam * diam * vrat);
 _p[_dlist1[16]] /= ( diam * diam * vrat);
 _p[_dlist1[17]] /= ( diam * diam * vrat);
 _p[_dlist1[18]] /= ( ( 1e10 ) * parea);
   } return _reset;
 }
 
/*CVODE matsol*/
 static int _ode_matsol1(void* _so, double* _rhs, double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {int _reset=0;{
 double b_flux, f_flux, _term; int _i;
   b_flux = f_flux = 0.;
 {int _i; double _dt1 = 1.0/dt;
for(_i=0;_i<19;_i++){
  	_RHS1(_i) = _dt1*(_p[_dlist1[_i]]);
	_MATELM1(_i, _i) = _dt1;
      
}  
_RHS1(0) *= ( ( 1e10 ) * parea) ;
_MATELM1(0, 0) *= ( ( 1e10 ) * parea); 
_RHS1(1) *= ( diam * diam * vrat) ;
_MATELM1(1, 1) *= ( diam * diam * vrat); 
_RHS1(2) *= ( diam * diam * vrat) ;
_MATELM1(2, 2) *= ( diam * diam * vrat); 
_RHS1(3) *= ( diam * diam * vrat) ;
_MATELM1(3, 3) *= ( diam * diam * vrat); 
_RHS1(4) *= ( diam * diam * vrat) ;
_MATELM1(4, 4) *= ( diam * diam * vrat); 
_RHS1(5) *= ( diam * diam * vrat) ;
_MATELM1(5, 5) *= ( diam * diam * vrat); 
_RHS1(6) *= ( diam * diam * vrat) ;
_MATELM1(6, 6) *= ( diam * diam * vrat); 
_RHS1(7) *= ( diam * diam * vrat) ;
_MATELM1(7, 7) *= ( diam * diam * vrat); 
_RHS1(8) *= ( diam * diam * vrat) ;
_MATELM1(8, 8) *= ( diam * diam * vrat); 
_RHS1(9) *= ( diam * diam * vrat) ;
_MATELM1(9, 9) *= ( diam * diam * vrat); 
_RHS1(10) *= ( diam * diam * vrat) ;
_MATELM1(10, 10) *= ( diam * diam * vrat); 
_RHS1(11) *= ( diam * diam * vrat) ;
_MATELM1(11, 11) *= ( diam * diam * vrat); 
_RHS1(12) *= ( diam * diam * vrat) ;
_MATELM1(12, 12) *= ( diam * diam * vrat); 
_RHS1(13) *= ( diam * diam * vrat) ;
_MATELM1(13, 13) *= ( diam * diam * vrat); 
_RHS1(14) *= ( diam * diam * vrat) ;
_MATELM1(14, 14) *= ( diam * diam * vrat); 
_RHS1(15) *= ( diam * diam * vrat) ;
_MATELM1(15, 15) *= ( diam * diam * vrat); 
_RHS1(16) *= ( diam * diam * vrat) ;
_MATELM1(16, 16) *= ( diam * diam * vrat); 
_RHS1(17) *= ( diam * diam * vrat) ;
_MATELM1(17, 17) *= ( diam * diam * vrat); 
_RHS1(18) *= ( ( 1e10 ) * parea) ;
_MATELM1(18, 18) *= ( ( 1e10 ) * parea);  }
 /* COMPARTMENT diam * diam * vrat {
 ca mg Buff1 Buff1_ca Buff2 Buff2_ca BTC BTC_ca DMNPE DMNPE_ca CB CB_f_ca CB_ca_s CB_ca_ca PV PV_ca PV_mg }
 */
 /* COMPARTMENT ( 1e10 ) * parea {
 pump pumpca }
 */
 /* ~ ca + pump <-> pumpca ( kpmp1 * parea * ( 1e10 ) , kpmp2 * parea * ( 1e10 ) )*/
 _term =  kpmp1 * parea * ( 1e10 ) * ca ;
 _MATELM1( 18 ,18)  += _term;
 _MATELM1( 16 ,18)  += _term;
 _MATELM1( 0 ,18)  -= _term;
 _term =  kpmp1 * parea * ( 1e10 ) * pump ;
 _MATELM1( 18 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 0 ,16)  -= _term;
 _term =  kpmp2 * parea * ( 1e10 ) ;
 _MATELM1( 18 ,0)  -= _term;
 _MATELM1( 16 ,0)  -= _term;
 _MATELM1( 0 ,0)  += _term;
 /*REACTION*/
  /* ~ pumpca <-> pump ( kpmp3 * parea * ( 1e10 ) , 0.0 )*/
 _term =  kpmp3 * parea * ( 1e10 ) ;
 _MATELM1( 0 ,0)  += _term;
 _MATELM1( 18 ,0)  -= _term;
 _term =  0.0 ;
 _MATELM1( 0 ,18)  -= _term;
 _MATELM1( 18 ,18)  += _term;
 /* ~ ca < < ( - ica * PI * diam / ( 2.0 * FARADAY ) )*/
 /*FLUX*/
  _zdsq = diam * diam ;
 _zdsqvol = _zdsq * vrat ;
 /* ~ ca + Buff1 <-> Buff1_ca ( rf1 * _zdsqvol , rf2 * _zdsqvol )*/
 _term =  rf1 * _zdsqvol * ca ;
 _MATELM1( 6 ,6)  += _term;
 _MATELM1( 16 ,6)  += _term;
 _MATELM1( 5 ,6)  -= _term;
 _term =  rf1 * _zdsqvol * Buff1 ;
 _MATELM1( 6 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 5 ,16)  -= _term;
 _term =  rf2 * _zdsqvol ;
 _MATELM1( 6 ,5)  -= _term;
 _MATELM1( 16 ,5)  -= _term;
 _MATELM1( 5 ,5)  += _term;
 /*REACTION*/
  /* ~ ca + Buff2 <-> Buff2_ca ( rf3 * _zdsqvol , rf4 * _zdsqvol )*/
 _term =  rf3 * _zdsqvol * ca ;
 _MATELM1( 4 ,4)  += _term;
 _MATELM1( 16 ,4)  += _term;
 _MATELM1( 3 ,4)  -= _term;
 _term =  rf3 * _zdsqvol * Buff2 ;
 _MATELM1( 4 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 3 ,16)  -= _term;
 _term =  rf4 * _zdsqvol ;
 _MATELM1( 4 ,3)  -= _term;
 _MATELM1( 16 ,3)  -= _term;
 _MATELM1( 3 ,3)  += _term;
 /*REACTION*/
  /* ~ ca + BTC <-> BTC_ca ( b1 * _zdsqvol , b2 * _zdsqvol )*/
 _term =  b1 * _zdsqvol * ca ;
 _MATELM1( 2 ,2)  += _term;
 _MATELM1( 16 ,2)  += _term;
 _MATELM1( 1 ,2)  -= _term;
 _term =  b1 * _zdsqvol * BTC ;
 _MATELM1( 2 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 1 ,16)  -= _term;
 _term =  b2 * _zdsqvol ;
 _MATELM1( 2 ,1)  -= _term;
 _MATELM1( 16 ,1)  -= _term;
 _MATELM1( 1 ,1)  += _term;
 /*REACTION*/
  /* ~ ca + DMNPE <-> DMNPE_ca ( c1 * _zdsqvol , c2 * _zdsqvol )*/
 _term =  c1 * _zdsqvol * ca ;
 _MATELM1( 12 ,12)  += _term;
 _MATELM1( 16 ,12)  += _term;
 _MATELM1( 11 ,12)  -= _term;
 _term =  c1 * _zdsqvol * DMNPE ;
 _MATELM1( 12 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 11 ,16)  -= _term;
 _term =  c2 * _zdsqvol ;
 _MATELM1( 12 ,11)  -= _term;
 _MATELM1( 16 ,11)  -= _term;
 _MATELM1( 11 ,11)  += _term;
 /*REACTION*/
  /* ~ ca + CB <-> CB_ca_s ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 16 ,10)  += _term;
 _MATELM1( 8 ,10)  -= _term;
 _term =  nf1 * _zdsqvol * CB ;
 _MATELM1( 10 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 8 ,16)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 10 ,8)  -= _term;
 _MATELM1( 16 ,8)  -= _term;
 _MATELM1( 8 ,8)  += _term;
 /*REACTION*/
  /* ~ ca + CB <-> CB_f_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca ;
 _MATELM1( 10 ,10)  += _term;
 _MATELM1( 16 ,10)  += _term;
 _MATELM1( 9 ,10)  -= _term;
 _term =  ns1 * _zdsqvol * CB ;
 _MATELM1( 10 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 9 ,16)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 10 ,9)  -= _term;
 _MATELM1( 16 ,9)  -= _term;
 _MATELM1( 9 ,9)  += _term;
 /*REACTION*/
  /* ~ ca + CB_f_ca <-> CB_ca_ca ( nf1 * _zdsqvol , nf2 * _zdsqvol )*/
 _term =  nf1 * _zdsqvol * ca ;
 _MATELM1( 9 ,9)  += _term;
 _MATELM1( 16 ,9)  += _term;
 _MATELM1( 7 ,9)  -= _term;
 _term =  nf1 * _zdsqvol * CB_f_ca ;
 _MATELM1( 9 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 7 ,16)  -= _term;
 _term =  nf2 * _zdsqvol ;
 _MATELM1( 9 ,7)  -= _term;
 _MATELM1( 16 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ ca + CB_ca_s <-> CB_ca_ca ( ns1 * _zdsqvol , ns2 * _zdsqvol )*/
 _term =  ns1 * _zdsqvol * ca ;
 _MATELM1( 8 ,8)  += _term;
 _MATELM1( 16 ,8)  += _term;
 _MATELM1( 7 ,8)  -= _term;
 _term =  ns1 * _zdsqvol * CB_ca_s ;
 _MATELM1( 8 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 7 ,16)  -= _term;
 _term =  ns2 * _zdsqvol ;
 _MATELM1( 8 ,7)  -= _term;
 _MATELM1( 16 ,7)  -= _term;
 _MATELM1( 7 ,7)  += _term;
 /*REACTION*/
  /* ~ ca + PV <-> PV_ca ( m1 * _zdsqvol , m2 * _zdsqvol )*/
 _term =  m1 * _zdsqvol * ca ;
 _MATELM1( 15 ,15)  += _term;
 _MATELM1( 16 ,15)  += _term;
 _MATELM1( 14 ,15)  -= _term;
 _term =  m1 * _zdsqvol * PV ;
 _MATELM1( 15 ,16)  += _term;
 _MATELM1( 16 ,16)  += _term;
 _MATELM1( 14 ,16)  -= _term;
 _term =  m2 * _zdsqvol ;
 _MATELM1( 15 ,14)  -= _term;
 _MATELM1( 16 ,14)  -= _term;
 _MATELM1( 14 ,14)  += _term;
 /*REACTION*/
  /* ~ mg + PV <-> PV_mg ( p1 * _zdsqvol , p2 * _zdsqvol )*/
 _term =  p1 * _zdsqvol * mg ;
 _MATELM1( 15 ,15)  += _term;
 _MATELM1( 17 ,15)  += _term;
 _MATELM1( 13 ,15)  -= _term;
 _term =  p1 * _zdsqvol * PV ;
 _MATELM1( 15 ,17)  += _term;
 _MATELM1( 17 ,17)  += _term;
 _MATELM1( 13 ,17)  -= _term;
 _term =  p2 * _zdsqvol ;
 _MATELM1( 15 ,13)  -= _term;
 _MATELM1( 17 ,13)  -= _term;
 _MATELM1( 13 ,13)  += _term;
 /*REACTION*/
  cai = ca ;
 mgi = mg ;
   } return _reset;
 }
 
/*CVODE end*/
 
static int _ode_count(int _type){ return 19;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
     _ode_spec1 (_p, _ppvar, _thread, _nt);
  _ion_cai = cai;
 }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
	double* _p; Datum* _ppvar;
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 19; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 static void _ode_synonym(int _cnt, double** _pp, Datum** _ppd) { 
	double* _p; Datum* _ppvar;
 	int _i; 
	for (_i=0; _i < _cnt; ++_i) {_p = _pp[_i]; _ppvar = _ppd[_i];
 _ion_cai =  ca ;
 }}
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   double* _p; Datum* _ppvar; Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 _cvode_sparse_thread(&_thread[_cvspth1]._pvoid, 19, _dlist1, _p, _ode_matsol1, _ppvar, _thread, _nt);
 }}
 
static void _thread_mem_init(Datum* _thread) {
   _thread[2]._pval = (double*)ecalloc(3, sizeof(double));
 }
 
static void _thread_cleanup(Datum* _thread) {
   _nrn_destroy_sparseobj_thread(_thread[_cvspth1]._pvoid);
   _nrn_destroy_sparseobj_thread(_thread[_spth1]._pvoid);
   free((void*)(_thread[2]._pval));
 }
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_ca_sym, _ppvar, 0, 2);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 1, 1);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 2, 3);
 }

static void initmodel(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt) {
  int _i; double _save;{
  BTC_ca = BTC_ca0;
  BTC = BTC0;
  Buff2_ca = Buff2_ca0;
  Buff2 = Buff20;
  Buff1_ca = Buff1_ca0;
  Buff1 = Buff10;
  CB_ca_ca = CB_ca_ca0;
  CB_ca_s = CB_ca_s0;
  CB_f_ca = CB_f_ca0;
  CB = CB0;
  DMNPE_ca = DMNPE_ca0;
  DMNPE = DMNPE0;
  PV_mg = PV_mg0;
  PV_ca = PV_ca0;
  PV = PV0;
  ca = ca0;
  mg = mg0;
  pumpca = pumpca0;
  pump = pump0;
 {
   factors ( _threadargs_ ) ;
   ca = cainull ;
   mg = mginull ;
   Buff1 = ssBuff1 ( _threadargs_ ) ;
   Buff1_ca = ssBuff1ca ( _threadargs_ ) ;
   Buff2 = ssBuff2 ( _threadargs_ ) ;
   Buff2_ca = ssBuff2ca ( _threadargs_ ) ;
   BTC = ssBTC ( _threadargs_ ) ;
   BTC_ca = ssBTCca ( _threadargs_ ) ;
   DMNPE = ssDMNPE ( _threadargs_ ) ;
   DMNPE_ca = ssDMNPEca ( _threadargs_ ) ;
   CB = ssCB ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
   CB_f_ca = ssCBfast ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
   CB_ca_s = ssCBslow ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
   CB_ca_ca = ssCBca ( _threadargscomma_ kdf ( _threadargs_ ) , kds ( _threadargs_ ) ) ;
   PV = ssPV ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
   PV_ca = ssPVca ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
   PV_mg = ssPVmg ( _threadargscomma_ kdc ( _threadargs_ ) , kdm ( _threadargs_ ) ) ;
   parea = PI * diam ;
   parea2 = PI * ( diam - 0.2 ) ;
   ica = 0.0 ;
   ica_pmp = 0.0 ;
   pump = TotalPump ;
   pumpca = 0.0 ;
   }
 
}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 initmodel(_p, _ppvar, _thread, _nt);
  _ion_cai = cai;
  nrn_wrote_conc(_ca_sym, (&(_ion_cai)) - 1, _style_ca);
}}

static double _nrn_current(double* _p, Datum* _ppvar, Datum* _thread, _NrnThread* _nt, double _v){double _current=0.;v=_v;{
} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type) {
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type) {
 double _break, _save;
double* _p; Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
_thread = _ml->_thread;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
  cao = _ion_cao;
  cai = _ion_cai;
  ica = _ion_ica;
  cai = _ion_cai;
 { {
 for (; t < _break; t += dt) {
  sparse_thread(&_thread[_spth1]._pvoid, 19, _slist1, _dlist1, _p, &t, dt, state, _linmat1, _ppvar, _thread, _nt);
  
}}
 t = _save;
 } {
   }
  _ion_cai = cai;
}}

}

static void terminal(){}

static void _initlists(){
 double _x; double* _p = &_x;
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(pumpca) - _p;  _dlist1[0] = &(Dpumpca) - _p;
 _slist1[1] = &(BTC_ca) - _p;  _dlist1[1] = &(DBTC_ca) - _p;
 _slist1[2] = &(BTC) - _p;  _dlist1[2] = &(DBTC) - _p;
 _slist1[3] = &(Buff2_ca) - _p;  _dlist1[3] = &(DBuff2_ca) - _p;
 _slist1[4] = &(Buff2) - _p;  _dlist1[4] = &(DBuff2) - _p;
 _slist1[5] = &(Buff1_ca) - _p;  _dlist1[5] = &(DBuff1_ca) - _p;
 _slist1[6] = &(Buff1) - _p;  _dlist1[6] = &(DBuff1) - _p;
 _slist1[7] = &(CB_ca_ca) - _p;  _dlist1[7] = &(DCB_ca_ca) - _p;
 _slist1[8] = &(CB_ca_s) - _p;  _dlist1[8] = &(DCB_ca_s) - _p;
 _slist1[9] = &(CB_f_ca) - _p;  _dlist1[9] = &(DCB_f_ca) - _p;
 _slist1[10] = &(CB) - _p;  _dlist1[10] = &(DCB) - _p;
 _slist1[11] = &(DMNPE_ca) - _p;  _dlist1[11] = &(DDMNPE_ca) - _p;
 _slist1[12] = &(DMNPE) - _p;  _dlist1[12] = &(DDMNPE) - _p;
 _slist1[13] = &(PV_mg) - _p;  _dlist1[13] = &(DPV_mg) - _p;
 _slist1[14] = &(PV_ca) - _p;  _dlist1[14] = &(DPV_ca) - _p;
 _slist1[15] = &(PV) - _p;  _dlist1[15] = &(DPV) - _p;
 _slist1[16] = &(ca) - _p;  _dlist1[16] = &(Dca) - _p;
 _slist1[17] = &(mg) - _p;  _dlist1[17] = &(Dmg) - _p;
 _slist1[18] = &(pump) - _p;  _dlist1[18] = &(Dpump) - _p;
_first = 0;
}

#if defined(__cplusplus)
} /* extern "C" */
#endif
