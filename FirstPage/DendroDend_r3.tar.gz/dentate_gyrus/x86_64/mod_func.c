#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _bgka_reg(void);
extern void _CaBK_reg(void);
extern void _ccanl_reg(void);
extern void _Gfluct2_reg(void);
extern void _gskch_reg(void);
extern void _hyperde3_reg(void);
extern void _ichan2_reg(void);
extern void _inhsyn_reg(void);
extern void _LcaMig_reg(void);
extern void _nca_reg(void);
extern void _ppsyn_reg(void);
extern void _tca_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/bgka.mod");
    fprintf(stderr," mod_nsgportal/CaBK.mod");
    fprintf(stderr," mod_nsgportal/ccanl.mod");
    fprintf(stderr," mod_nsgportal/Gfluct2.mod");
    fprintf(stderr," mod_nsgportal/gskch.mod");
    fprintf(stderr," mod_nsgportal/hyperde3.mod");
    fprintf(stderr," mod_nsgportal/ichan2.mod");
    fprintf(stderr," mod_nsgportal/inhsyn.mod");
    fprintf(stderr," mod_nsgportal/LcaMig.mod");
    fprintf(stderr," mod_nsgportal/nca.mod");
    fprintf(stderr," mod_nsgportal/ppsyn.mod");
    fprintf(stderr," mod_nsgportal/tca.mod");
    fprintf(stderr, "\n");
  }
  _bgka_reg();
  _CaBK_reg();
  _ccanl_reg();
  _Gfluct2_reg();
  _gskch_reg();
  _hyperde3_reg();
  _ichan2_reg();
  _inhsyn_reg();
  _LcaMig_reg();
  _nca_reg();
  _ppsyn_reg();
  _tca_reg();
}
