#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _fh_reg(void);
extern void _kca_reg(void);
extern void _klt_reg(void);
extern void _kml_reg(void);
extern void _leak_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/fh.mod");
    fprintf(stderr," mod_nsgportal/kca.mod");
    fprintf(stderr," mod_nsgportal/klt.mod");
    fprintf(stderr," mod_nsgportal/kml.mod");
    fprintf(stderr," mod_nsgportal/leak.mod");
    fprintf(stderr, "\n");
  }
  _fh_reg();
  _kca_reg();
  _klt_reg();
  _kml_reg();
  _leak_reg();
}
