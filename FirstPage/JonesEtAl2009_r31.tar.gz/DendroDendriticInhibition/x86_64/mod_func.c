#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _cadecay_reg(void);
extern void _currentGauss_reg(void);
extern void _flushf_reg(void);
extern void _GradGABAa_reg(void);
extern void _ipscGauss_reg(void);
extern void _kA_reg(void);
extern void _kca_reg(void);
extern void _kfasttab_reg(void);
extern void _kM_reg(void);
extern void _kslowtab_reg(void);
extern void _lcafixed_reg(void);
extern void _nafast_reg(void);
extern void _nagran_reg(void);
extern void _nmdanet_reg(void);
extern void _shuntInhib_reg(void);
extern void _stim2_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/cadecay.mod");
    fprintf(stderr," mod_nsgportal/currentGauss.mod");
    fprintf(stderr," mod_nsgportal/flushf.mod");
    fprintf(stderr," mod_nsgportal/GradGABAa.mod");
    fprintf(stderr," mod_nsgportal/ipscGauss.mod");
    fprintf(stderr," mod_nsgportal/kA.mod");
    fprintf(stderr," mod_nsgportal/kca.mod");
    fprintf(stderr," mod_nsgportal/kfasttab.mod");
    fprintf(stderr," mod_nsgportal/kM.mod");
    fprintf(stderr," mod_nsgportal/kslowtab.mod");
    fprintf(stderr," mod_nsgportal/lcafixed.mod");
    fprintf(stderr," mod_nsgportal/nafast.mod");
    fprintf(stderr," mod_nsgportal/nagran.mod");
    fprintf(stderr," mod_nsgportal/nmdanet.mod");
    fprintf(stderr," mod_nsgportal/shuntInhib.mod");
    fprintf(stderr," mod_nsgportal/stim2.mod");
    fprintf(stderr, "\n");
  }
  _cadecay_reg();
  _currentGauss_reg();
  _flushf_reg();
  _GradGABAa_reg();
  _ipscGauss_reg();
  _kA_reg();
  _kca_reg();
  _kfasttab_reg();
  _kM_reg();
  _kslowtab_reg();
  _lcafixed_reg();
  _nafast_reg();
  _nagran_reg();
  _nmdanet_reg();
  _shuntInhib_reg();
  _stim2_reg();
}
