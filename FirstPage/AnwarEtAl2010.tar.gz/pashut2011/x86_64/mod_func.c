#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _cad2_reg(void);
extern void _childa_reg(void);
extern void _child_reg(void);
extern void _epsp_reg(void);
extern void _it2_reg(void);
extern void _kaprox_reg(void);
extern void _kca_reg(void);
extern void _km_reg(void);
extern void _kv_reg(void);
extern void _na_reg(void);
extern void _SlowCa_reg(void);
extern void _xtra_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/cad2.mod");
    fprintf(stderr," mod_nsgportal/childa.mod");
    fprintf(stderr," mod_nsgportal/child.mod");
    fprintf(stderr," mod_nsgportal/epsp.mod");
    fprintf(stderr," mod_nsgportal/it2.mod");
    fprintf(stderr," mod_nsgportal/kaprox.mod");
    fprintf(stderr," mod_nsgportal/kca.mod");
    fprintf(stderr," mod_nsgportal/km.mod");
    fprintf(stderr," mod_nsgportal/kv.mod");
    fprintf(stderr," mod_nsgportal/na.mod");
    fprintf(stderr," mod_nsgportal/SlowCa.mod");
    fprintf(stderr," mod_nsgportal/xtra.mod");
    fprintf(stderr, "\n");
  }
  _cad2_reg();
  _childa_reg();
  _child_reg();
  _epsp_reg();
  _it2_reg();
  _kaprox_reg();
  _kca_reg();
  _km_reg();
  _kv_reg();
  _na_reg();
  _SlowCa_reg();
  _xtra_reg();
}
