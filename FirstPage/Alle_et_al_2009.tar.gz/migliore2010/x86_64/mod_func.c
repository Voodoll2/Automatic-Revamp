#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _ampanmda_reg(void);
extern void _fi_reg(void);
extern void _kamt_reg(void);
extern void _kdrmt_reg(void);
extern void _naxn_reg(void);
extern void _ThreshDetect_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/ampanmda.mod");
    fprintf(stderr," mod_nsgportal/fi.mod");
    fprintf(stderr," mod_nsgportal/kamt.mod");
    fprintf(stderr," mod_nsgportal/kdrmt.mod");
    fprintf(stderr," mod_nsgportal/naxn.mod");
    fprintf(stderr," mod_nsgportal/ThreshDetect.mod");
    fprintf(stderr, "\n");
  }
  _ampanmda_reg();
  _fi_reg();
  _kamt_reg();
  _kdrmt_reg();
  _naxn_reg();
  _ThreshDetect_reg();
}
