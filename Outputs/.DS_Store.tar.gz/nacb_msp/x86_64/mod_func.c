#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _AMPA_reg(void);
extern void _bkkca_reg(void);
extern void _cadyn_reg(void);
extern void _caL13_reg(void);
extern void _caldyn_reg(void);
extern void _caL_reg(void);
extern void _can_reg(void);
extern void _caq_reg(void);
extern void _car_reg(void);
extern void _cat_reg(void);
extern void _GABA_reg(void);
extern void _kaf_reg(void);
extern void _kas_reg(void);
extern void _kir_reg(void);
extern void _krp_reg(void);
extern void _naf_reg(void);
extern void _nap_reg(void);
extern void _NMDA_reg(void);
extern void _skkca_reg(void);
extern void _stim_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/AMPA.mod");
    fprintf(stderr," mod_nsgportal/bkkca.mod");
    fprintf(stderr," mod_nsgportal/cadyn.mod");
    fprintf(stderr," mod_nsgportal/caL13.mod");
    fprintf(stderr," mod_nsgportal/caldyn.mod");
    fprintf(stderr," mod_nsgportal/caL.mod");
    fprintf(stderr," mod_nsgportal/can.mod");
    fprintf(stderr," mod_nsgportal/caq.mod");
    fprintf(stderr," mod_nsgportal/car.mod");
    fprintf(stderr," mod_nsgportal/cat.mod");
    fprintf(stderr," mod_nsgportal/GABA.mod");
    fprintf(stderr," mod_nsgportal/kaf.mod");
    fprintf(stderr," mod_nsgportal/kas.mod");
    fprintf(stderr," mod_nsgportal/kir.mod");
    fprintf(stderr," mod_nsgportal/krp.mod");
    fprintf(stderr," mod_nsgportal/naf.mod");
    fprintf(stderr," mod_nsgportal/nap.mod");
    fprintf(stderr," mod_nsgportal/NMDA.mod");
    fprintf(stderr," mod_nsgportal/skkca.mod");
    fprintf(stderr," mod_nsgportal/stim.mod");
    fprintf(stderr, "\n");
  }
  _AMPA_reg();
  _bkkca_reg();
  _cadyn_reg();
  _caL13_reg();
  _caldyn_reg();
  _caL_reg();
  _can_reg();
  _caq_reg();
  _car_reg();
  _cat_reg();
  _GABA_reg();
  _kaf_reg();
  _kas_reg();
  _kir_reg();
  _krp_reg();
  _naf_reg();
  _nap_reg();
  _NMDA_reg();
  _skkca_reg();
  _stim_reg();
}
